Program: CALM
version: v1.2
Title: CALM: A software tool for rapid analysis and modelling of converted shear wave in wide-angle seismic data
Author: Haoyu Zhang
Address: University of Chinese Academy of sciences
        South China Sea Institute of Chinese Academy of sciences
e-mail: haoyuzhang@scsio.ac.cn
        xlqiu@scsio.ac.cn

