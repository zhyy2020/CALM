# -*- coding: utf-8 -*-
"""
Created on Tue Jan  7 00:10:09 2020

@author: ZHY
"""

import numpy as np
#import scipy
from scipy.optimize import fsolve
from math import cos, sin, asin, pi
#A, R, B, a11, a12, a13, a14, a21, a22, a23, a24, a31, a32, a33, a34, a41, a42, a43, a44 = symbols('A R B a11 a12 a13 a14 a21 a22 a23 a24 a31 a32 a33 a34 a41 a42 a43 a44')
#alpha, beta, alpha1, beta1 = symbols('alpha beta alpha1 beta1')

#a11, a12, a21, a22 = symbols('a11 a12 a21 a22')
def Zoeppritz_solver(alpha, Vp1, Vs1, ro1, Vp2, Vs2, ro2):
    #alpha is in arc instead of degree
    # All parameters are in international standard unit! such as m/s, kg/m^3
    #return [Rpp, Rps, Tpp, Tps] 
    
#    alpha=0.2500000*pi
#    Vp1 = 6.9*1000
#    Vp2 = 7.9*1000
#    Vs1 = 3.88*1000
#    Vs2 = 4.39*1000
#    ro1 = 2.8*1000
#    ro2 = 3.3*1000
    
    if Vp2*sin(alpha)/Vp1 > 1.0:
        alpha1 = 0.500000*pi
    else:
        alpha1 = asin(Vp2*sin(alpha)/Vp1)
    #alpha1 = asin(Vp2*sin(alpha)/Vp1)
        
    if Vs1*sin(alpha)/Vp1 > 1.0:
        beta = 0.500000*pi
    else:
        beta = asin(Vs1*sin(alpha)/Vp1)
    #beta = asin(Vs1*sin(alpha)/Vp1)
        
    if Vs2*sin(alpha)/Vp1 > 1.0:
        beta1 = 0.500000*pi
    else:
        beta1 = asin(Vs2*sin(alpha)/Vp1)
    #beta1 = asin(Vs2*sin(alpha)/Vp1)
        
    #alpha1 = asin(Vp2*sin(alpha)/Vp1);
    #beta = asin(Vs1*sin(alpha)/Vp1);
    #beta1 = asin(Vs2*sin(alpha)/Vp1);
    
    a11 = sin(alpha)
    a12 = cos(beta)
    a13 = -sin(alpha1)
    a14 = cos(beta1)
    a21 = cos(alpha)
    a22 = -sin(beta)
    a23 = cos(alpha1)
    a24 = sin(beta1)
    a31 = cos(2*beta)
    a32 = -Vs1/Vp1*sin(2*beta)
    a33 = -ro2/ro1*Vp2/Vp1*cos(2*beta1)
    a34 = -ro2/ro1*Vs2/Vp1*sin(2*beta1)
    a41 = Vs1*Vs1/Vp1*sin(2*alpha)
    a42 = Vs1*cos(2*beta)
    a43 = ro2/ro1*Vs2*Vs2/Vp2*sin(2*alpha1)
    a44 = -ro2/ro1*Vs2*cos(2*beta1)
    b1 = -sin(alpha)
    b2 = cos(alpha)
    b3 = -cos(2*beta)
    b4 = Vs1*Vs1/Vp1*sin(2*alpha)
    
    
    
    def f4(x):
        return np.array([a11*x[0] + a12*x[1] + a13*x[2] + a14*x[3] - b1,\
                         a21*x[0] + a22*x[1] + a23*x[2] + a24*x[3] - b2,\
                         a31*x[0] + a32*x[1] + a33*x[2] + a34*x[3] - b3,\
                         a41*x[0] + a42*x[1] + a43*x[2] + a44*x[3] - b4])
    
    
    #sol_root = root(f4, [0,0,0,0])
    sol_fsolve = fsolve(f4,[0.0, 0.0, 0.0, 0.0])
    return sol_fsolve