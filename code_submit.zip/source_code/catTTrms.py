# -*- coding: utf-8 -*-
"""
Created on Mon Aug 12 09:31:59 2019

@author: ZHY
"""

def catTTrmsEach(No, fileName, calInfoArr, phaseNo, calInfoOverall):
    from collections import deque
    fileObj = open(fileName, 'r')
    last30Lines = deque(fileObj, 300)
    list1 = list(last30Lines)
#300是一个足够大的数，能够包含近所有的行，因为在这里是从文件的最后开始一次性读进去300行
    pts = 0
    rms = 0
    chi2 = 0
    for line in list1:
        if "Number of data points used:" in line:
            line_elem = line.split()
            pts = int(line_elem[-1])
        elif "RMS traveltime residual:" in line:
            line_elem = line.split()
            rms = float(line_elem[-1])
        elif "Normalized chi-squared:" in line:
            line_elem = line.split()
            chi2 = float(line_elem[-1])
        else:
            pass
            #print("Not matched!\n")
    print(pts,rms,chi2)
    calInfoOverall[No] = (pts, rms, chi2)
    for line in list1:
        line_elem = line.split()
        if len(line_elem) != 4:
            continue
        
        if line_elem[0] in phaseNo:
            calInfoArr[No][int(int(line_elem[0]))] = \
            (int(line_elem[1]), float(line_elem[2]),float(line_elem[3]))
            print(No, line_elem[0], calInfoArr[No][int(int(line_elem[0]))])
            
    fileObj.close()
    
    return calInfoArr,calInfoOverall

def catTTrmsPhase(phaseNo, OBSNo, calInfoArr, calInfoOverall):
    fid_temp = open("calInfoSum.txt", 'w')
    cur_pts_sum = 0
    cur_rms = 0
    cur_chi2 = 0
#    rms = 0
#    chi2 = 0
    for phase in phaseNo:
        phase = int(phase)
        cur_pts_sum = 0
        cur_rms = 0
        cur_chi2 = 0
        for OBS in OBSNo:
            OBS = int(OBS)
            if type(calInfoArr[OBS][phase]) is int:
                continue
            cur_pts_sum = calInfoArr[OBS][phase][0] + cur_pts_sum
        for OBS in OBSNo:
            OBS = int(OBS)
            if type(calInfoArr[OBS][phase]) is int:
                continue
            cur_rms = calInfoArr[OBS][phase][0]*calInfoArr[OBS][phase][1]/float(cur_pts_sum) + cur_rms
            cur_chi2 = calInfoArr[OBS][phase][0]*calInfoArr[OBS][phase][2]/float(cur_pts_sum) + cur_chi2
        fid_temp.write("%2d%6d%10.6f%9.6f\n" %(phase,cur_pts_sum, cur_rms, cur_chi2))
     
    cur_pts_sum = 0
    cur_rms = 0
    cur_chi2 = 0  
    for i in range(1,len(calInfoOverall)):
        cur_pts_sum = cur_pts_sum +  calInfoOverall[i][0];
        fid_temp.write("%6d%10.6f%9.6f\n" %(calInfoOverall[i][0], calInfoOverall[i][1], calInfoOverall[i][2]))
    pts_sum = cur_pts_sum
    for i in range(1,len(calInfoOverall)):
         
        cur_rms = calInfoOverall[i][1] * calInfoOverall[i][0]/float(pts_sum) + cur_rms;
        cur_chi2 = calInfoOverall[i][2] * calInfoOverall[i][0]/float(pts_sum) + cur_chi2;
    fid_temp.write("%6d%10.6f%9.6f\n" %(pts_sum, cur_rms, cur_chi2))
    fid_temp.close()        

def catTTrmsEachStation(filename):
    from collections import deque
    fileObj = open(filename, 'r')
    last30Lines = deque(fileObj, 300)
    list1 = list(last30Lines)
#30是一个足够大的数，能够包含近所有的行，因为在这里是从文件的最后开始一次性读进去30行
    pts = 0
    rms = 0
    chi2 = 0
    for line in list1:
        if "Number of data points used:" in line:
            line_elem = line.split()
            pts = int(line_elem[-1])
        elif "RMS traveltime residual:" in line:
            line_elem = line.split()
            rms = float(line_elem[-1])
        elif "Normalized chi-squared:" in line:
            line_elem = line.split()
            chi2 = float(line_elem[-1])
        else:
            pass
            #print("Not matched!\n")
    fileObj.close()
    return pts,rms,chi2
            
    
    
   

    
    