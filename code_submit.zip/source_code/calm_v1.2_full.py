# -*- coding: utf-8 -*-
"""
Created on Wed Nov 20 10:56:20 2019
Modification to v1.0: v1.1 this version is capable of dealing with 3 layers at a time.
Modification 2020.05.13  We can analysis for spatial variations of conversion efficiency.
Modification to v1.1: v1.2 add output files in analysis module.

@author: Haoyu Zhang
@e-mail: haoyuzhang@scsio.ac.cn

"""

import tkinter
from tkinter import messagebox
#from tkinter import ttk
from tkinter import scrolledtext
from tkinter import filedialog
import os
from datetime import datetime
from math import pi
#import shutil
#import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
#import numpy as np

from read_write_r_bulk_pois import read_write_r_bulk_pois
from read_write_r_bulk_pois import read_write_r_layers_blocks_pois
import tracing_evaluate
from Zoeppritz_solver_integral import Zoeppritz_solver_integral
from vmodel import vmodel


class simpleapp_tk(tkinter.Tk):
    def __init__(self,parent):
        tkinter.Tk.__init__(self,parent)
        self.parent = parent
        self.initialize()

    def initialize(self):
        #The color of background 
        #self.configure(background="seashell")
        #The size of window
        winWidth = 1400
        winHeight = 800
        #Size of screen
        screenWidth = self.winfo_screenwidth()
        screenHeight = self.winfo_screenheight()
        #To Ensure that the window is on the center of screen.
        x = int((screenWidth - winWidth) / 2)
        y = int((screenHeight - winHeight) / 2)
        self.geometry("%sx%s+%s+%s" % (winWidth, winHeight, x, y))
        #Keep it Scalable and setting the icon picture. 
        self.resizable(1,1)
        self.iconbitmap("calm.ico")
        
        #Initialization of reference points dictionary and spacing of rows.
        self.refer_pts = {}
        self.row_spacing = 30
        #Initialization of Button attributes dictionary.
        self.button_attr = {}
        self.button_attr["bg"] = "SkyBlue"
        self.button_attr["activebackground"] = "Gold"
        self.button_attr["font"] = ("Arial", 10, "bold")
        self.button_attr["relief"] = "groove"
        self.button_attr["file_icon"] = "f3.ico"
        
        self.bar_attr = {}
        self.bar_attr["bg"] = "SkyBlue"
        self.bar_attr["fill"] = "green"
        
        #Setting file path of velocity model including label, button and text entry.
        self.refer_pts["vmodel_input"] = [700, 30]
        self.vmodel_file_path = tkinter.StringVar()
        self.vmodel_file_path.set(os.getcwd())
        self.label_vmodel = tkinter.Label(self,text='v.in').place(x=self.refer_pts["vmodel_input"][0], y=self.refer_pts["vmodel_input"][1])
        self.entry_vmodel = tkinter.Entry(self,textvariable=self.vmodel_file_path, width=60).place(x=self.refer_pts["vmodel_input"][0]+30, y=self.refer_pts["vmodel_input"][1])
        self.button_vmodel_select = tkinter.Button(self, bg=self.button_attr["bg"], activebackground=self.button_attr["activebackground"],font=self.button_attr["font"], relief=self.button_attr["relief"], \
                                                   text='Select', command=self.show_file_dialog_vmodel).place(\
                                                  x=self.refer_pts["vmodel_input"][0]+480, y=self.refer_pts["vmodel_input"][1]-5)
        
        #Button for parsing of velocity model.
        self.button_vmodel_parse = tkinter.Button(self, bg=self.button_attr["bg"], activebackground=self.button_attr["activebackground"],font=self.button_attr["font"], relief=self.button_attr["relief"], \
                                                  text='Parse', command=self.vmodel_parse).place(\
                                                  x=self.refer_pts["vmodel_input"][0]+540, y=self.refer_pts["vmodel_input"][1]-5)
        
        #Setting module for number of layers in the model.
        self.layers_num = tkinter.IntVar()
        self.layers_num.set(6)
        self.label_layers_num = tkinter.Label(self,text='Layers Number').place(x=self.refer_pts["vmodel_input"][0], y=self.refer_pts["vmodel_input"][1]+30)
        self.entry_layers_num = tkinter.Entry(self, highlightcolor="Gold", relief="groove", textvariable=self.layers_num, width=5).place(x=self.refer_pts["vmodel_input"][0]+100, y=self.refer_pts["vmodel_input"][1]+30)
        
        #Setting module for distance limitation of model.
        self.vmodel_x_min = tkinter.StringVar()
        self.vmodel_x_min.set('0.0')
        self.label_vmodel_x_min = tkinter.Label(self,text='Distance Min (km)').place(x=self.refer_pts["vmodel_input"][0]+160, y=self.refer_pts["vmodel_input"][1]+30)
        self.entry_vmodel_x_min = tkinter.Entry(self, textvariable=self.vmodel_x_min, width=10).place(x=self.refer_pts["vmodel_input"][0]+280, y=self.refer_pts["vmodel_input"][1]+30)
        
        self.vmodel_x_max = tkinter.StringVar()
        self.vmodel_x_max.set('240.0')
        self.label_vmodel_x_max = tkinter.Label(self,text='Max (km)').place(x=self.refer_pts["vmodel_input"][0]+360, y=self.refer_pts["vmodel_input"][1]+30)
        self.entry_vmodel_x_max = tkinter.Entry(self, textvariable=self.vmodel_x_max, width=10).place(x=self.refer_pts["vmodel_input"][0]+430, y=self.refer_pts["vmodel_input"][1]+30)
        
        #Initialization of vmodel subject for velocity model.
        self.vmodel = 0
        
        #Setting buttons in mode analysis module.
        self.button_vmodel_plot = tkinter.Button(self,  bg=self.button_attr["bg"], activebackground=self.button_attr["activebackground"],font=self.button_attr["font"], relief=self.button_attr["relief"], \
                                                 text='Visualize', command=self.vmodel_plot).place(\
                                                  x=self.refer_pts["vmodel_input"][0]+120, y=self.refer_pts["vmodel_input"][1]+60-5)
        
        self.button_vmodel_erase = tkinter.Button(self,  bg=self.button_attr["bg"], activebackground=self.button_attr["activebackground"],font=self.button_attr["font"], relief=self.button_attr["relief"], \
                                                  text='Erase', command=self.vmodel_erase).place(\
                                                  x=self.refer_pts["vmodel_input"][0]+360, y=self.refer_pts["vmodel_input"][1]+60-5)
        
#        self.button_interface_select = tkinter.Button(self,  bg=self.button_attr["bg"], activebackground=self.button_attr["activebackground"],font=self.button_attr["font"], relief=self.button_attr["relief"], \
#                                                      text='Select Conversion Interface', command=self.select_interface).place(\
#                                                  x=self.refer_pts["vmodel_input"][0]+160, y=self.refer_pts["vmodel_input"][1]+60-5)
        
        #Setting for Dispaly Area.
        self.refer_pts["model_display"] = [700, 120]
        self.model_fig = Figure(figsize=(6,4), dpi=100, facecolor="white", edgecolor="red", frameon=True)
        self.model_fig_plotted_flag = 0
        
        #Setting for canvas in Display Area
        self.model_canvas = FigureCanvasTkAgg(self.model_fig,self)
        self.model_canvas.draw()
        self.model_canvas.get_tk_widget().place(x=self.refer_pts["model_display"][0], y=self.refer_pts["model_display"][1])
        self.model_canvas_toolbar = NavigationToolbar2Tk(self.model_canvas, self)
        self.model_canvas_toolbar.place(x=self.refer_pts["model_display"][0]+150, y=self.refer_pts["model_display"][1]+410)
        self.model_fig_axs = self.model_fig.add_subplot(111)
        
        #Staust bar at the bottom of the window.
        self.status = tkinter.StringVar()
        self.status.set("Converted wAve veLocity Modelling")
        self.status_label = tkinter.Label(self, textvariable=self.status, anchor='c')
        self.status_label.pack(side=tkinter.BOTTOM)
        
        #Setting the bounds and step in linear search.
        self.refer_pts["search_set"] = [10, 30]
        
        #layer1
        self.search_layer1_vpvs_min = tkinter.StringVar()
        self.search_layer1_vpvs_max = tkinter.StringVar()
        self.search_layer1_vpvs_step = tkinter.StringVar()
        
        self.search_layer1_vpvs_min.set('2.0')
        self.search_layer1_vpvs_max.set('5.1')
        self.search_layer1_vpvs_step.set('0.1')
        
        
        self.entry_search_layer1_vpvs_min = tkinter.Entry(self,textvariable=self.search_layer1_vpvs_min,width=10).place(x=self.refer_pts["search_set"][0]+140,y=self.refer_pts["search_set"][1])
        self.entry_search_layer1_vpvs_max = tkinter.Entry(self,textvariable=self.search_layer1_vpvs_max,width=10).place(x=self.refer_pts["search_set"][0]+250,y=self.refer_pts["search_set"][1])
        self.entry_search_layer1_vpvs_step = tkinter.Entry(self,textvariable=self.search_layer1_vpvs_step,width=10).place(x=self.refer_pts["search_set"][0]+380,y=self.refer_pts["search_set"][1])
        
        self.label_search_layer1_vpvs_min = tkinter.Label(self,text='Layer1 Vp/Vs ratio Min').place(x=self.refer_pts["search_set"][0],y=self.refer_pts["search_set"][1])
        self.label_search_layer1_vpvs_max = tkinter.Label(self,text='Max').place(x=self.refer_pts["search_set"][0]+210,y=self.refer_pts["search_set"][1])
        self.label_search_layer1_vpvs_step = tkinter.Label(self,text='Step').place(x=self.refer_pts["search_set"][0]+340,y=self.refer_pts["search_set"][1])
        
        
        #layer2
        self.search_layer2_vpvs_min = tkinter.StringVar()
        self.search_layer2_vpvs_max = tkinter.StringVar()
        self.search_layer2_vpvs_step = tkinter.StringVar()
        
        self.search_layer2_vpvs_min.set('2.0')
        self.search_layer2_vpvs_max.set('5.1')
        self.search_layer2_vpvs_step.set('0.1')
        
        
        
        self.entry_search_layer2_vpvs_min = tkinter.Entry(self,textvariable=self.search_layer2_vpvs_min,width=10).place(x=self.refer_pts["search_set"][0]+140,y=self.refer_pts["search_set"][1]+self.row_spacing)
        self.entry_search_layer2_vpvs_max = tkinter.Entry(self,textvariable=self.search_layer2_vpvs_max,width=10).place(x=self.refer_pts["search_set"][0]+250,y=self.refer_pts["search_set"][1]+self.row_spacing)
        self.entry_search_layer2_vpvs_step = tkinter.Entry(self,textvariable=self.search_layer2_vpvs_step,width=10).place(x=self.refer_pts["search_set"][0]+380,y=self.refer_pts["search_set"][1]+self.row_spacing)
        
        self.label_search_layer2_vpvs_min = tkinter.Label(self,text='Layer2 Vp/Vs ratio Min').place(x=self.refer_pts["search_set"][0],y=self.refer_pts["search_set"][1]+self.row_spacing)
        self.label_search_layer2_vpvs_max = tkinter.Label(self,text='Max').place(x=self.refer_pts["search_set"][0]+210,y=self.refer_pts["search_set"][1]+self.row_spacing)
        self.label_search_layer2_vpvs_step = tkinter.Label(self,text='Step').place(x=self.refer_pts["search_set"][0]+340,y=self.refer_pts["search_set"][1]+self.row_spacing)
        
        
        #layer3
        self.search_layer3_vpvs_min = tkinter.StringVar()
        self.search_layer3_vpvs_max = tkinter.StringVar()
        self.search_layer3_vpvs_step = tkinter.StringVar()
        
        self.search_layer3_vpvs_min.set('2.0')
        self.search_layer3_vpvs_max.set('5.1')
        self.search_layer3_vpvs_step.set('0.1')
        
        
        
        self.entry_search_layer3_vpvs_min = tkinter.Entry(self,textvariable=self.search_layer3_vpvs_min,width=10).place(x=self.refer_pts["search_set"][0]+140,y=self.refer_pts["search_set"][1]+2*self.row_spacing)
        self.entry_search_layer3_vpvs_max = tkinter.Entry(self,textvariable=self.search_layer3_vpvs_max,width=10).place(x=self.refer_pts["search_set"][0]+250,y=self.refer_pts["search_set"][1]+2*self.row_spacing)
        self.entry_search_layer3_vpvs_step = tkinter.Entry(self,textvariable=self.search_layer3_vpvs_step,width=10).place(x=self.refer_pts["search_set"][0]+380,y=self.refer_pts["search_set"][1]+2*self.row_spacing)
        
        self.label_search_layer3_vpvs_min = tkinter.Label(self,text='Layer3 Vp/Vs ratio Min').place(x=self.refer_pts["search_set"][0],y=self.refer_pts["search_set"][1]+2*self.row_spacing)
        self.label_search_layer3_vpvs_max = tkinter.Label(self,text='Max').place(x=self.refer_pts["search_set"][0]+210,y=self.refer_pts["search_set"][1]+2*self.row_spacing)
        self.label_search_layer3_vpvs_step = tkinter.Label(self,text='Step').place(x=self.refer_pts["search_set"][0]+340,y=self.refer_pts["search_set"][1]+2*self.row_spacing)
        
        #Setting data directory
        self.refer_pts["data_directory"] = [10, 360]
        
        self.data_directory = tkinter.StringVar()
        self.data_directory.set(os.getcwd())
        self.label_data_directory = tkinter.Label(self,text='Data Directory').place(x=self.refer_pts["data_directory"][0],y=self.refer_pts["data_directory"][1])
        self.entry_data_directory = tkinter.Entry(self,textvariable=self.data_directory,width=60).place(x=self.refer_pts["data_directory"][0]+100,y=self.refer_pts["data_directory"][1])
        
        
        #Specification of layers to be searched
        self.search_layer1_no = tkinter.IntVar()
        self.search_layer1_no.set('2')
        self.label_search_layer1_no = tkinter.Label(self,text='Layer1 No').place(x=self.refer_pts["search_set"][0],y=self.refer_pts["search_set"][1]+3*self.row_spacing)
        self.entry_search_layer1_no = tkinter.Entry(self,textvariable=self.search_layer1_no,width=10).place(x=self.refer_pts["search_set"][0]+140,y=self.refer_pts["search_set"][1]+3*self.row_spacing)
        
        self.search_layer2_no = tkinter.IntVar()
        self.search_layer2_no.set('3')
        self.label_search_layer2_no = tkinter.Label(self,text='Layer2 No').place(x=self.refer_pts["search_set"][0]+210,y=self.refer_pts["search_set"][1]+3*self.row_spacing)
        self.entry_search_layer2_no = tkinter.Entry(self,textvariable=self.search_layer2_no,width=10).place(x=self.refer_pts["search_set"][0]+280,y=self.refer_pts["search_set"][1]+3*self.row_spacing)
        
        self.search_layer3_no = tkinter.IntVar()
        self.search_layer3_no.set('0')
        self.label_search_layer2_no = tkinter.Label(self,text='Layer3 No').place(x=self.refer_pts["search_set"][0]+380,y=self.refer_pts["search_set"][1]+3*self.row_spacing)
        self.entry_search_layer2_no = tkinter.Entry(self,textvariable=self.search_layer3_no,width=10).place(x=self.refer_pts["search_set"][0]+450,y=self.refer_pts["search_set"][1]+3*self.row_spacing)
        
        #Setting reduced velocity in phases plotting.
        self.reduced_vel = tkinter.StringVar()
        self.reduced_vel.set('6.0')
        self.label_reduced_vel = tkinter.Label(self, text="Reduced Vel.(km/s)").place(x=self.refer_pts["search_set"][0]+360,y=self.refer_pts["search_set"][1]+4*self.row_spacing)
        self.entry_reduced_vel = tkinter.Entry(self,textvariable=self.reduced_vel,width=5).place(x=self.refer_pts["search_set"][0]+485,y=self.refer_pts["search_set"][1]+4*self.row_spacing)
        
        #Setting test directory for intermediate files generated in each model run.
        self.test_directory = tkinter.StringVar()
        self.test_directory.set("test_bulk_pois")
        self.label_test_directory = tkinter.Label(self,text='Test Folder').place(x=self.refer_pts["search_set"][0],y=self.refer_pts["search_set"][1]+4*self.row_spacing)
        self.entry_test_directory = tkinter.Entry(self,textvariable=self.test_directory,width=30).place(x=self.refer_pts["search_set"][0]+140,y=self.refer_pts["search_set"][1]+4*self.row_spacing)
        
        
        
        #Setting model file selection module
        self.refer_pts["model_file_select"] = [538, 360]
        self.button_data_directory_select = tkinter.Button(self, bg=self.button_attr["bg"], activebackground=self.button_attr["activebackground"],font=self.button_attr["font"], relief=self.button_attr["relief"], \
                                            text='select', command=self.show_file_dialog).place(x=self.refer_pts["model_file_select"][0],y=self.refer_pts["model_file_select"][1])
        
        #Setting progress bar
        self.refer_pts["progress_bar"] = [100, 390]
        self.canvas_progress_text = tkinter.Label(self, text = "Progress Bar").place(x=self.refer_pts["progress_bar"][0]-90,y=self.refer_pts["progress_bar"][1])
        self.canvas_progress_bar = tkinter.Canvas(self,width=300,height=20,bg = self.bar_attr["bg"])
        self.canvas_progress_bar.place(x=self.refer_pts["progress_bar"][0],y=self.refer_pts["progress_bar"][1])
        self.perc_search_run = tkinter.StringVar()
        self.progress_bar_out_rec = self.canvas_progress_bar.create_rectangle(0,0,300,30,outline='',width=1)
        self.progress_bar_fill_rec = self.canvas_progress_bar.create_rectangle(0,0,0,30,outline = '',width = 0,fill = self.bar_attr["fill"])
        
        self.label_perc_search_run = tkinter.Label(self,textvariable=self.perc_search_run,width=15).place(x=self.refer_pts["progress_bar"][0]+400,y=self.refer_pts["progress_bar"][1])
        
        self.search_run_remain_time = tkinter.StringVar()
        self.label_search_run_remain_time = tkinter.Label(self,textvariable=self.search_run_remain_time,width=15).place(x=self.refer_pts["progress_bar"][0]+450,y=self.refer_pts["progress_bar"][1])
        
        #Setting entry of initial values array of poisson's values.
        self.refer_pts["layer_pois"] = [10, 220]
        self.layer_pois = tkinter.StringVar()
        self.layer_pois.set('0.5,0.4205,0.3755,0.2616,0.269,0.235')
        self.label_layer_pois = tkinter.Label(self,text='Layer Pois. ratio').place(x=self.refer_pts["layer_pois"][0], y=self.refer_pts["layer_pois"][1])
        self.entry_layer_pois = tkinter.Entry(self,textvariable=self.layer_pois,width=55).place(x=self.refer_pts["layer_pois"][0]+105, y=self.refer_pts["layer_pois"][1])
        
        #Check button for search mode
        self.refer_pts["search_mode"] = [10, 260]
        self.search_mode_no = tkinter.IntVar() 
        self.search_mode_no_check1 = tkinter.Radiobutton(self, text='Layer Mode', variable=self.search_mode_no, value=1, command=self.radio_select1).place(x=self.refer_pts["search_mode"][0], y=self.refer_pts["search_mode"][1])
        self.search_mode_no_check2 = tkinter.Radiobutton(self, text='Block Mode', variable=self.search_mode_no, value=2, command=self.radio_select2).place(x=self.refer_pts["search_mode"][0], y=self.refer_pts["search_mode"][1]+self.row_spacing)
        
        #Requisite paramters for 'Block' search mode, blocks in two layers.
        self.refer_pts["block_set"] = [130, 262]
        self.block_min1 = tkinter.IntVar()
        self.block_min1.set(0)
        self.block_min1_label = tkinter.Label(self,text='Block Min 1').place(x=self.refer_pts["block_set"][0],y=self.refer_pts["block_set"][1])
        self.block_min1_entry = tkinter.Entry(self,textvariable=self.block_min1, width=10).place(x=self.refer_pts["block_set"][0]+100,y=self.refer_pts["block_set"][1])
        
        self.block_max1 = tkinter.IntVar()
        self.block_max1.set(0)
        self.block_max1_label = tkinter.Label(self,text='Block Max 1').place(x=self.refer_pts["block_set"][0]+200, y=self.refer_pts["block_set"][1])
        self.block_max1_entry = tkinter.Entry(self,textvariable=self.block_max1, width=10).place(x=self.refer_pts["block_set"][0]+300, y=self.refer_pts["block_set"][1])
        
        self.block_min2 = tkinter.IntVar()
        self.block_min2.set(0)
        self.block_min2_label = tkinter.Label(self,text='Block Min 2').place(x=self.refer_pts["block_set"][0], y=self.refer_pts["block_set"][1]+self.row_spacing)
        self.block_min2_entry = tkinter.Entry(self,textvariable=self.block_min2, width=10).place(x=self.refer_pts["block_set"][0]+100, y=self.refer_pts["block_set"][1]+self.row_spacing)
        
        self.block_max2 = tkinter.IntVar()
        self.block_max2.set(0)
        self.block_max2_label = tkinter.Label(self,text='Block Max 2').place(x=self.refer_pts["block_set"][0]+200,y=self.refer_pts["block_set"][1]+self.row_spacing)
        self.block_max2_entry = tkinter.Entry(self,textvariable=self.block_max2, width=10).place(x=self.refer_pts["block_set"][0]+300, y=self.refer_pts["block_set"][1]+self.row_spacing)
        
        self.block_min3 = tkinter.IntVar()
        self.block_min3.set(0)
        self.block_min3_label = tkinter.Label(self,text='Block Min 3').place(x=self.refer_pts["block_set"][0], y=self.refer_pts["block_set"][1]+2*self.row_spacing)
        self.block_min3_entry = tkinter.Entry(self,textvariable=self.block_min3, width=10).place(x=self.refer_pts["block_set"][0]+100, y=self.refer_pts["block_set"][1]+2*self.row_spacing)
        
        self.block_max3 = tkinter.IntVar()
        self.block_max3.set(0)
        self.block_max3_label = tkinter.Label(self,text='Block Max 3').place(x=self.refer_pts["block_set"][0]+200,y=self.refer_pts["block_set"][1]+2*self.row_spacing)
        self.block_max3_entry = tkinter.Entry(self,textvariable=self.block_max3, width=10).place(x=self.refer_pts["block_set"][0]+300, y=self.refer_pts["block_set"][1]+2*self.row_spacing)
        
        #Setting search run button
        self.button_search_run = tkinter.Button(self, bg=self.button_attr["bg"], activebackground=self.button_attr["activebackground"],font=self.button_attr["font"], relief=self.button_attr["relief"], \
                                      height=3, width=6, text='Run',command=self.OnRunClick).place(x=self.refer_pts["block_set"][0]+400, y=self.refer_pts["block_set"][1])
        
        # Module for results of search, including prefix of filename of file storing results of search.
        self.refer_pts["result"] = [10, 430]
        self.result_filename_prefix = tkinter.StringVar()
        self.result_filename_prefix.set('results_vpvs')
        self.label_result_filename_prefix = tkinter.Label(self,text='Prefix').place(x=self.refer_pts["result"][0], y=self.refer_pts["result"][1])
        self.entry_result_filename_prefix = tkinter.Entry(self,textvariable=self.result_filename_prefix, width=40).place(x=self.refer_pts["result"][0]+40, y=self.refer_pts["result"][1])
        
        #shape factor is used in model evaluation.
        self.shape_factor = tkinter.StringVar()
        self.shape_factor.set('1.0')
#        self.shape_factor_label = tkinter.Label(self,text='Shape Factor').place(x=self.refer_pts["result"][0]+200, y=self.refer_pts["result"][1])
#        self.shape_factor_entry = tkinter.Entry(self,textvariable=self.shape_factor, width=10).place(x=self.refer_pts["result"][0]+300, y=self.refer_pts["result"][1])
        
        #chi2_square_share is used in used in model evaluation, which controls the relative importance of traveltime misfit to evaluation scores.
        self.chi2_square_share = tkinter.StringVar()
        self.chi2_square_share.set('0.90')
        self.chi2_square_share_label = tkinter.Label(self,text='Chi2_share').place(x=self.refer_pts["result"][0]+350, y=self.refer_pts["result"][1])
        self.chi2_square_share_entry = tkinter.Entry(self,textvariable=self.chi2_square_share, width=10).place(x=self.refer_pts["result"][0]+430, y=self.refer_pts["result"][1])
        
        #Setting evaluate, phases plotting button
        self.refer_pts["evaluation"] = [10, 470]
        self.button_search_evaluate = tkinter.Button(self, bg=self.button_attr["bg"], activebackground=self.button_attr["activebackground"],font=self.button_attr["font"], relief=self.button_attr["relief"], \
                                      text='Evaluate',command=self.results_evaluate).place(x=self.refer_pts["evaluation"][0]+120, y=self.refer_pts["evaluation"][1])
        self.button_plot_phases_rays = tkinter.Button(self, bg=self.button_attr["bg"], activebackground=self.button_attr["activebackground"],font=self.button_attr["font"], relief=self.button_attr["relief"], \
                                      text='Plot Phases traced',command=self.plot_phases_rays).place(x=self.refer_pts["evaluation"][0]+320, y=self.refer_pts["evaluation"][1])
        
        
        #vp/vs ratio to poisson's ratio convertor setting
        
        self.cal_vpvs = tkinter.StringVar()
        self.cal_vpvs.set('1.732')
        self.cal_vpvs_label = tkinter.Label(self, text='Vp/Vs ratio').place(x=self.refer_pts["search_set"][0],y=self.refer_pts["search_set"][1]+5*self.row_spacing)
        self.cal_vpvs_entry = tkinter.Entry(self,textvariable=self.cal_vpvs, width=10).place(x=self.refer_pts["search_set"][0]+140,y=self.refer_pts["search_set"][1]+5*self.row_spacing)
        
        self.button_convert1 = tkinter.Button(self, bg=self.button_attr["bg"], activebackground=self.button_attr["activebackground"],font=self.button_attr["font"], relief=self.button_attr["relief"], \
                                              text='==>',command=self.OnConvert1Click).place(x=self.refer_pts["search_set"][0]+240,y=self.refer_pts["search_set"][1]+5*self.row_spacing)
        
        self.button_convert2 = tkinter.Button(self, bg=self.button_attr["bg"], activebackground=self.button_attr["activebackground"],font=self.button_attr["font"], relief=self.button_attr["relief"], \
                                              text='<==',command=self.OnConvert2Click).place(x=self.refer_pts["search_set"][0]+300,y=self.refer_pts["search_set"][1]+5*self.row_spacing)
        
        self.cal_pois = tkinter.StringVar()
        self.cal_pois.set('0.250')
        self.cal_pois_label = tkinter.Label(self, text="Poisson's ratio").place(x=self.refer_pts["search_set"][0]+350, y=self.refer_pts["search_set"][1]+5*self.row_spacing)
        self.cal_pois_entry = tkinter.Entry(self,textvariable=self.cal_pois, width=10).place(x=self.refer_pts["search_set"][0]+450, y=self.refer_pts["search_set"][1]+5*self.row_spacing)
        
        # conversion mode/interface analysis module
        #self.refer_pts['mode'] = [10, 480] #on the left
        self.refer_pts['mode'] = [700, 590] #on the right
        
        self.mode_vp1 = tkinter.StringVar()
        self.mode_vp1.set('6900.0')
        self.mode_vp1_label = tkinter.Label(self, text='Vp1').place(x=self.refer_pts['mode'][0], y=self.refer_pts['mode'][1])
        self.mode_vp1_entry = tkinter.Entry(self,textvariable=self.mode_vp1, width=15).place(x=self.refer_pts['mode'][0]+40, y=self.refer_pts['mode'][1])
        
        self.mode_vs1 = tkinter.StringVar()
        self.mode_vs1.set('3880.0')
        self.mode_vs1_label = tkinter.Label(self, text='Vs1').place(x=self.refer_pts['mode'][0]+180, y=self.refer_pts['mode'][1])
        self.mode_vs1_entry = tkinter.Entry(self,textvariable=self.mode_vs1, width=15).place(x=self.refer_pts['mode'][0]+220,y=self.refer_pts['mode'][1])
        
        self.mode_ro1 = tkinter.StringVar()
        self.mode_ro1.set('2800.0')
        self.mode_ro1_label = tkinter.Label(self, text='Density 1').place(x=self.refer_pts['mode'][0]+360, y=self.refer_pts['mode'][1])
        self.mode_ro1_entry = tkinter.Entry(self,textvariable=self.mode_ro1, width=15).place(x=self.refer_pts['mode'][0]+430,y=self.refer_pts['mode'][1])
        
        self.mode_vp2 = tkinter.StringVar()
        self.mode_vp2.set('7900.0')
        self.mode_vp2_label = tkinter.Label(self, text='Vp2').place(x=self.refer_pts['mode'][0], y=self.refer_pts['mode'][1]+self.row_spacing)
        self.mode_vp2_entry = tkinter.Entry(self,textvariable=self.mode_vp2, width=15).place(x=self.refer_pts['mode'][0]+40, y=self.refer_pts['mode'][1]+self.row_spacing)
        
        self.mode_vs2 = tkinter.StringVar()
        self.mode_vs2.set('4390.0')
        self.mode_vs2_label = tkinter.Label(self, text='Vs2').place(x=self.refer_pts['mode'][0]+180, y=self.refer_pts['mode'][1]+self.row_spacing)
        self.mode_vs2_entry = tkinter.Entry(self,textvariable=self.mode_vs2, width=15).place(x=self.refer_pts['mode'][0]+220,y=self.refer_pts['mode'][1]+self.row_spacing)
        
        self.mode_ro2 = tkinter.StringVar()
        self.mode_ro2.set('3300.0')
        self.mode_ro2_label = tkinter.Label(self, text='Density 2').place(x=self.refer_pts['mode'][0]+360, y=self.refer_pts['mode'][1]+self.row_spacing)
        self.mode_ro2_entry = tkinter.Entry(self,textvariable=self.mode_ro2, width=15).place(x=self.refer_pts['mode'][0]+430,y=self.refer_pts['mode'][1]+self.row_spacing)
        
        # alpha1, alpha2 and step determines the range of incodent angles to be calculated in conversion mode analysis.
        self.mode_alpha1 = tkinter.StringVar()
        self.mode_alpha1.set('0.0')
        self.mode_alpha1_label = tkinter.Label(self, text='Angle Min').place(x=self.refer_pts['mode'][0], y=self.refer_pts['mode'][1]+2*self.row_spacing)
        self.mode_alpha1_entry = tkinter.Entry(self,textvariable=self.mode_alpha1, width=10).place(x=self.refer_pts['mode'][0]+75, y=self.refer_pts['mode'][1]+2*self.row_spacing)
        
        self.mode_alpha2 = tkinter.StringVar()
        self.mode_alpha2.set('90.0')
        self.mode_alpha2_label = tkinter.Label(self, text='Angle Max').place(x=self.refer_pts['mode'][0]+180, y=self.refer_pts['mode'][1]+2*self.row_spacing)
        self.mode_alpha2_entry = tkinter.Entry(self,textvariable=self.mode_alpha2, width=10).place(x=self.refer_pts['mode'][0]+255,y=self.refer_pts['mode'][1]+2*self.row_spacing)
        
        self.mode_alpha_step = tkinter.StringVar()
        self.mode_alpha_step.set('1.0')
        self.mode_alpha_step_label = tkinter.Label(self, text='Step').place(x=self.refer_pts['mode'][0]+360, y=self.refer_pts['mode'][1]+2*self.row_spacing)
        self.mode_alpha_step_entry = tkinter.Entry(self,textvariable=self.mode_alpha_step, width=15).place(x=self.refer_pts['mode'][0]+430,y=self.refer_pts['mode'][1]+2*self.row_spacing)
        
        # conversion mode (interface) analysis Button
        self.button_interface_select = tkinter.Button(self,  bg=self.button_attr["bg"], activebackground=self.button_attr["activebackground"],font=self.button_attr["font"], relief=self.button_attr["relief"], \
                                                      text='Select Interface', command=self.select_interface).place(\
                                                  x=self.refer_pts['mode'][0], y=self.refer_pts['mode'][1]+4*self.row_spacing)
        
        self.button_mode_analysis = tkinter.Button(self, bg=self.button_attr["bg"], activebackground=self.button_attr["activebackground"],font=self.button_attr["font"], relief=self.button_attr["relief"], \
                                                   text='Mode Analy.',command=self.OnModeAnalysisClick).place(x=self.refer_pts['mode'][0]+130, y=self.refer_pts['mode'][1]+4*self.row_spacing)
        
        self.button_mode_analysis_varia = tkinter.Button(self, bg=self.button_attr["bg"], activebackground=self.button_attr["activebackground"],font=self.button_attr["font"], relief=self.button_attr["relief"], \
                                                   text='Mode Varia.',command=self.OnModeAnalysisSpatialClick).place(x=self.refer_pts['mode'][0]+240, y=self.refer_pts['mode'][1]+4*self.row_spacing)
        
        self.button_mode_visualize = tkinter.Button(self, bg=self.button_attr["bg"], activebackground=self.button_attr["activebackground"],font=self.button_attr["font"], relief=self.button_attr["relief"], \
                                                   text='Visualize',command=self.Zoeppritz_RT_plot).place(x=self.refer_pts['mode'][0]+350, y=self.refer_pts['mode'][1]+4*self.row_spacing)
        
        
        self.mode_analysis_visual_no = tkinter.IntVar()
        self.mode_analysis_visual_no_check1 = tkinter.Radiobutton(self, text='Single Site.', variable=self.mode_analysis_visual_no, value=1, command=self.mode_analysis_visual_radio_select1_func).place\
        (x=self.refer_pts['mode'][0]+450, y=self.refer_pts['mode'][1]+int(3.5*self.row_spacing))
        self.mode_analysis_visual_no_check2 = tkinter.Radiobutton(self, text='Spac. Varia.', variable=self.mode_analysis_visual_no, value=2, command=self.mode_analysis_visual_radio_select2_func).place\
        (x=self.refer_pts['mode'][0]+450, y=self.refer_pts['mode'][1]+int(4.2*self.row_spacing))
        
        #Tips for parameters in mode analysis
        self.mode_tips1 = tkinter.Label(self, text='Tips: Vp Vs are in m/s; Density in kg/m^3; Incident Angle in degree.').place(x=self.refer_pts['mode'][0], y=self.refer_pts['mode'][1]+3*self.row_spacing)
        
        
        
        #Initialization of parameters used in manual selection.
        self.mode_vp2_select = 0.0
        self.mode_vp1_select = 0.0
        self.mode_vs2_select = 0.0
        self.mode_vs1_select = 0.0
        self.mode_ro2_select = 0.0
        self.mode_ro1_select = 0.0
        self.mode_interface_select = 666
        self.mode_upward_downward_incident = 0
        
        self.Rpp_fraction_temp = 0
        self.Rps_fraction_temp = 0
        self.Tpp_fraction_temp = 0
        self.Tps_fraction_temp = 0
        
        self.mode_analysis_Tpp_varia_list = []
        self.mode_analysis_Tps_varia_list = []
        self.mode_analysis_Rpp_varia_list = []
        self.mode_analysis_Rps_varia_list = []
        
        self.mode_analysis_varia_distance_list = []
        
        #Setting of scrolled text area.
        self.refer_pts["show_text"] = [15, 510]
        
        self.show_text = scrolledtext.ScrolledText(self, width=85, height=18)
        self.show_text.place(x=self.refer_pts["show_text"][0], y=self.refer_pts["show_text"][1])
        
        # Selected points in vlocity model plotting.
        self.pts_ginput = [[],[]]
        
        # Some other initialization
        [self.Rpp_mean, self.Rps_mean, self.Tpp_mean, self.Tps_mean] =[0,0,0,0]
        [self.Rpp_list, self.Rps_list, self.Tpp_list, self.Tps_list] =[[],[],[],[]]
        self.alpha1 = 0
        self.alpha2 = 0
        self.alpha_step = 1.0
        
        
    def results_evaluate(self):
        # Subfunction to call function 'trace_evaluate' to evaluate the model and print necessary results on the text area. 
        max_score,max_score_vpvs_key,results_list=\
        tracing_evaluate.evaluate(self.data_directory.get(), self.result_filename_prefix.get(), float(self.chi2_square_share.get()))
        vpvs_poisson_key_split = max_score_vpvs_key.split(' ')
        #self.show_text.insert(tkinter.END, 'max tracing score: '+str(max_score)+'\n')
        self.show_text.insert(tkinter.END, "----------------------Evaluation---------------------------\n")
        self.show_text.insert(tkinter.END, "-------------------chi_square share %s-------------------\n" %(self.chi2_square_share.get()))
        self.show_text.insert(tkinter.END, "Vp/Vs ratio 1        2        Poisson's ratio 1      2\n")
        self.show_text.insert(tkinter.END, "%13.5f   %8.5f %17.6f        %8.6f\n" %(float(vpvs_poisson_key_split[0]), float(vpvs_poisson_key_split[1]),float(vpvs_poisson_key_split[2]),float(vpvs_poisson_key_split[3])))
        #self.show_text.insert(tkinter.END, max_score_vpvs_key + '\n')
        self.show_text.insert(tkinter.END, "traced number       rms[s]     chi_square         score\n")
        self.show_text.insert(tkinter.END, "%13.0f   %8.5f %17.6f        %8.6f\n" %(results_list[0], results_list[1],results_list[2],results_list[3]))
        #self.show_text.insert(tkinter.END, results_list)
        self.show_text.insert(tkinter.END, '\n')
        
    def vmodel_parse(self):
        # Parse the P-wave velocity model using 'vmodel' module.
        # After this operation, the velocity model is parsed and written to self.vmodel 
        os.chdir(self.vmodel_file_path.get())
        layers_number = self.layers_num.get()
        x_min = float(self.vmodel_x_min.get())
        x_max = float(self.vmodel_x_max.get())
        self.vmodel = vmodel("v.in", layers_number, x_min, x_max)
        self.show_text.insert(tkinter.END, "\nVp model in v.in is parsed!\n")
        
    def vmodel_plot(self):
        # This subfunction is capable of plotting velocity model in display area.
        # It utilizes external library 'matplotlib'. 
        self.model_fig.clear()
        self.model_fig_axs = self.model_fig.add_subplot(111)
        self.model_fig_axs.clear()
        
        for i in range(0, len(self.vmodel.dn_z),1):
            self.model_fig_axs.plot(self.vmodel.dn_x[i],self.vmodel.dn_z[i],'b.-',linewidth=1)
        
        self.model_fig_axs.set_xlim((float(self.vmodel_x_min.get()),float(self.vmodel_x_max.get())))
        self.model_fig_axs.set_ylim((self.vmodel.dn_z[0][0], self.vmodel.dn_z[-1][0]))
        
        self.model_fig_axs.invert_yaxis()
        self.model_fig_axs.set_xlabel("Distance (km)")
        self.model_fig_axs.set_ylabel("Depth (km)")
        self.model_fig_axs.set_title("Interfaces in Model")
        
        self.model_canvas.draw()
        
    def plot_phases_rays(self):
        # This subfunction is capable of plotting velocity model, picked phases, traced rays and caculated traveltimes in display area.
        # It utilizes external library 'matplotlib'. 
        self.model_fig.clear()
        self.model_fig_axs = self.model_fig.add_subplot(211)
        self.model_fig_axs.clear()
        
        os.chdir(self.data_directory.get())
        
        #the set containing observation poistions of picked phases that can be used to discriminate the valid rays in r2.out
        observation_x_set = set()
        with open("tx.in", 'r') as tx_fid:
            for line in tx_fid:
                elems = line.strip().split()
                phase_no = int(elems[3])
                observation_x = round(float(elems[0])*1000)/1000.0
                if phase_no not in [0,-1]:
                    observation_x_set.add(observation_x)
        
                 
        #r2.out contains the detialed information of each ray. this part extracts valid rays from it.
        #Only the rays reached observation poisition on the surface is considered valid.        
        with open("r2.out", 'r') as r2_fid:
            read_flag = 0
            ray_set = []
            ray_pts = []
            z_temp = 10.0
            x0 = 6666666.6
            for line in r2_fid:
                elems = line.strip().split()
                #The lines behind the line with this feature are sources from which we extract the rays. 
                if len(elems) == 13 and elems[0] == "gr":
                    read_flag = 1
                    continue
                #make sure line read is valid or not.    
                if read_flag == 1 and len(elems)>7:
                    line = line.strip()
                    
                    
                    if line[0] != '*':
                        #in fact, we have more valid information under this condition.
                        npt = int(line[5:9])
                        x = float(line[9:17])
                        z = float(line[17:25])

                    else:
                        npt = int(line[5:9])
                        x = float(line[9:17])
                        z = float(line[17:25])
                    #npt==1 is symbolic of new ray.
                    if npt == 1:
                        #check if the ray collected just now is valid.
                        if len(ray_pts) != 0 and z_temp == 0.0 and x0 in observation_x_set:
                            ray_set.append(ray_pts)
                            pts_x = [a[0] for a in ray_pts]
                            pts_z = [a[1] for a in ray_pts]
                            self.model_fig_axs.plot(pts_x, pts_z, 'b', linewidth=0.8)
                            
                            ray_pts.clear()
                            
                        else:
                            ray_pts.clear()
                            
                    
                    z_temp = z
                    x0 = x
                    
                    
                    ray_pts.append([x,z])
                    
        self.model_fig_axs.set_xlim((float(self.vmodel_x_min.get()),float(self.vmodel_x_max.get())))
        self.model_fig_axs.set_ylim((self.vmodel.dn_z[0][0], self.vmodel.dn_z[-1][0]))
        self.model_fig_axs.invert_yaxis()
        self.model_fig_axs.set_xlabel("Distance (km)")
        self.model_fig_axs.set_ylabel("Depth (km)")
        self.model_fig_axs.set_title("Rays in Model / Observed and calculated Phases")
        
        
        
        #plot the velocity model.
        for i in range(0, len(self.vmodel.dn_z), 1):
            self.model_fig_axs.plot(self.vmodel.dn_x[i],self.vmodel.dn_z[i],'b.-',linewidth=1.0)
        
        
        
        self.model_fig_axs2 = self.model_fig.add_subplot(212)
        self.model_fig_axs2.clear()
        
        self.model_fig_axs2.invert_yaxis()
        self.model_fig_axs2.set_xlabel("Distance (km)")
        self.model_fig_axs2.set_ylabel("Time (s)")
        #self.model_fig_axs2.set_title("Observed and calculated Phases")
        
        #collect picked phases from tx.in and reduce the traveltime.
        with open("tx.in", 'r') as r2_fid:
            ob_dist = []
            ob_redu_t = []
            for line in r2_fid:
                elems = line.strip().split()
                if len(elems) == 4 and int(elems[3]) == 0:
                    receiv_x = float(elems[0])
                if len(elems) == 4 and int(elems[3]) not in [0, -1]:
                    line = line.strip()
                    ob_dist.append(float(elems[0]))
                    ob_redu_t.append(float(elems[1])-abs(float(elems[0])-receiv_x)/float(self.reduced_vel.get()))
                

        self.model_fig_axs2.plot(ob_dist, ob_redu_t, 'b.', markersize=2.0)

        #r1.out contains calculated traveltime for each ray.
        with open("r1.out", 'r') as r1_fid:
            dist = []
            redu_t = []
            for line in r1_fid:
                elems = line.strip().split()
                #check the current line is valid or not.
                if len(elems) > 7 and line[0] not in ['*', 's', '|', 'N', 'R','-']:
                    line = line.strip()
                    dist.append(float(line[26:36]))
                    redu_t.append(float(line[43:51]))
        
        self.model_fig_axs2.plot(dist, redu_t, 'r.', markersize=0.8)   

        
        self.model_canvas.draw()
        
        
    def vmodel_erase(self):
        #erase current figure on Display Area.
        self.model_fig_axs.clear()
        self.model_fig_plotted_flag = 0
        
        
    def select_interface(self):
        #this subfuction enables graphical interative selection of depth interfaces, two points each time.  
        if self.model_fig_axs == 0:
            messagebox.showinfo("Error Info", "You should plot the velocity model first!")
        else:
            #two points clicked each time
            self.pts_ginput = self.model_fig.ginput(n=2, timeout=180, show_clicks=True, mouse_add=1, mouse_pop=3, mouse_stop=2)
            self.show_text.insert(tkinter.END, "\nThe captuerd points:\n")
            self.show_text.insert(tkinter.END, self.pts_ginput)
            self.show_text.insert(tkinter.END, "\n")
            #determine which interface the point selected closest to
            [cur_interface1, cur_distance_to_interface1,upper_lower_flag1] = self.determine_interface(self.pts_ginput[0])
            self.show_text.insert(tkinter.END, "\nThe captuerd interface and its distance (km) to point 1:\n")
            self.show_text.insert(tkinter.END, [cur_interface1, cur_distance_to_interface1])
            self.show_text.insert(tkinter.END, "\n")
            [cur_interface2, cur_distance_to_interface2,upper_lower_flag2] = self.determine_interface(self.pts_ginput[1])
            self.show_text.insert(tkinter.END, "\nThe captuerd interface and its distance (km) to point 2:\n")
            self.show_text.insert(tkinter.END, [cur_interface2, cur_distance_to_interface2])
            self.show_text.insert(tkinter.END, "\n")
            # IF the two points are closest to the same interface (assumed case)
            if cur_interface1 == cur_interface2:
                #self.model_fig_axs.plot([self.pts_ginput[0][0], self.pts_ginput[1][0]],[self.pts_ginput[0][1], self.pts_ginput[1][1]], 'b.-', linewidth=1)
                self.model_fig_axs.arrow(self.pts_ginput[0][0], self.pts_ginput[0][1], self.pts_ginput[1][0]-self.pts_ginput[0][0], self.pts_ginput[1][1]-self.pts_ginput[0][1], capstyle='projecting', color='green',width=0.2, head_width=2.0, head_length=0.5)
                self.model_fig_axs.plot(self.vmodel.dn_x[cur_interface1],self.vmodel.dn_z[cur_interface1],'r.-',linewidth=1)
                self.model_canvas.draw()
                self.mode_interface_select = cur_interface1
            else:
                messagebox.showinfo("Error Info", "You should select the interaces again(Two points flanking the interface in sequence)!")
            
            # the first selected point is above the interface
            if upper_lower_flag1 == 1:
                self.mode_vp1_select = self.determine_upper_pts_P_velocity(self.pts_ginput[0], cur_interface1)
            # the first selected point is below the interface
            elif upper_lower_flag1 == -1:
                self.mode_vp1_select = self.determine_lower_pts_P_velocity(self.pts_ginput[0], cur_interface1)
            else:
                messagebox.showinfo("Error Info", "You should select the interaces again(Two points flanking the interface in sequence)!")
            
            # the second selected point is above the interface
            if upper_lower_flag2 == 1:
                # deternime the P-wave velocity based on its location.
                self.mode_vp2_select = self.determine_upper_pts_P_velocity(self.pts_ginput[1], cur_interface2)
            # the second selected point is below the interface
            elif upper_lower_flag2 == -1:
                self.mode_vp2_select = self.determine_lower_pts_P_velocity(self.pts_ginput[1], cur_interface2)
            else:
                messagebox.showinfo("Error Info", "You should select the interaces again(Two points flanking the interface in sequence)!")
            

            
            self.show_text.insert(tkinter.END, "\nThe P-wave velocity (km/s) of the selected points:\n%f %f\n" %(self.mode_vp1_select,self.mode_vp2_select))
            
            #setting vp and density of the selected points 
            self.mode_vp1.set("%6.2f" %(self.mode_vp1_select*1000.0))
            self.mode_vp2.set("%6.2f" %(self.mode_vp2_select*1000.0))
            
            self.mode_ro1_select = self.vp_to_density(self.mode_vp1_select, self.pts_ginput[0][1])
            self.mode_ro2_select = self.vp_to_density(self.mode_vp2_select, self.pts_ginput[1][1])
            
            self.mode_ro1.set("%6.2f" %(self.mode_ro1_select))
            self.mode_ro2.set("%6.2f" %(self.mode_ro2_select))
            
            self.mode_vs1_select = self.vp_to_vs(self.mode_vp1_select, cur_interface1, upper_lower_flag1)
            self.mode_vs2_select = self.vp_to_vs(self.mode_vp2_select, cur_interface2, upper_lower_flag2)
            
            self.mode_vs1.set("%6.2f" %(self.mode_vs1_select*1000.0))
            self.mode_vs2.set("%6.2f" %(self.mode_vs2_select*1000.0))
            
            if upper_lower_flag1 - upper_lower_flag2 == -2:
                self.show_text.insert(tkinter.END, "\nPPS conversion at interface %d.\n" %(cur_interface1))
                self.mode_upward_downward_incident = 1
            elif upper_lower_flag1 - upper_lower_flag2 == 2:
                self.show_text.insert(tkinter.END, "\nPSS conversion at interface %d.\n" %(cur_interface1))
                self.mode_upward_downward_incident = -1
            else:
                messagebox.showinfo("Error Info", "You should select the interaces again(Two points flanking the interface in sequence)!")
            
            
            
    
    def vp_to_density(self, vp, depth):
        #this law is after Christenson1995JGR [crust]
        #                  Hamilton1978 [sediments]
        
        # Hamilton1978
        if vp < 5.0:
           if depth < 0.5:
               ro_calc = 1.135*vp - 0.190
           else:
               ro_calc = 0.917 + 0.744*vp - 0.08*vp*vp
           #g/cm3 to kg/m3
           ro_calc *= 1000.0
        # Christenson1995JGR
        else:
            coeff_a_list = [4929.0, 5055.0, 5141.0, 5212.0, 5281.0]
            coeff_b_list = [-13294.0, -14094.0, -14539.0, -14863.0, -15174.0]
            depth_index = int(depth/10.0 + 0.5) - 1
            if depth_index > 4:
                depth = 4
            ro_calc = coeff_a_list[depth_index] + coeff_b_list[depth_index]/vp
        # this is oriented for seawater
        if vp < 1.56:
            ro_calc = 1030.0
        
        return ro_calc
        
    def vp_to_vs(self, vp, cur_interface, upper_lower_flag):
        # dividing Vp by the initial Vp/Vs ratio given above to get Vs
        temp_splited = self.layer_pois.get().strip().split(',')
        layer_pois_list = [float(elem) for elem in temp_splited]
        layer_vpvs_ratio_list = [ (float(2 - 2*pois_to_cal)/(1 - 2*pois_to_cal))**0.5 if pois_to_cal != 0.5 else float('inf') for pois_to_cal in layer_pois_list]
        temp_index = int(cur_interface - 0.5*upper_lower_flag - 0.5)
        vs = vp/layer_vpvs_ratio_list[temp_index]
        
        return vs
            

    def determine_upper_pts_P_velocity(self,pts_x_z,layer_no):
        # calculate the P-wave velocity of the selected point based on its relation to the velocity interface.
        # when this point is above the selected interface.
        v0 = 0.0
        layer_no = layer_no - 1
        for i in range(0,len(self.vmodel.lv_x[layer_no])-1,1):
            if (pts_x_z[0] - self.vmodel.lv_x[layer_no][i]) * (pts_x_z[0] - self.vmodel.lv_x[layer_no][i+1]) <= 0.0:
                v2 = self.vmodel.lv[layer_no][i+1]
                v1 = self.vmodel.lv[layer_no][i]
                x2 = self.vmodel.lv_x[layer_no][i+1]
                x1 = self.vmodel.lv_x[layer_no][i]
                x0 = pts_x_z[0]
                v0 = (v2 - v1)/(x2 - x1)*(x0 - x1) + v1
                break
        return v0

    def determine_lower_pts_P_velocity(self,pts_x_z,layer_no):
        # calculate the P-wave velocity of the selected point based on its relation to the velocity interface.
        # when this point is below the selected interface.
        v0 = 0.0
        for i in range(0,len(self.vmodel.uv_x[layer_no])-1,1):
            if (pts_x_z[0] - self.vmodel.uv_x[layer_no][i]) * (pts_x_z[0] - self.vmodel.uv_x[layer_no][i+1]) <= 0.0:
                v2 = self.vmodel.uv[layer_no][i+1]
                v1 = self.vmodel.uv[layer_no][i]
                x2 = self.vmodel.uv_x[layer_no][i+1]
                x1 = self.vmodel.uv_x[layer_no][i]
                x0 = pts_x_z[0]
                v0 = (v2 - v1)/(x2 - x1)*(x0 - x1) + v1
                break
        return v0      
                
        
            
        
            
    def determine_interface(self,pts_x_z):
        # Determine the interface that is closest to the selected point.
        cur_distance_to_interface = 1000000
        cur_interface = 0
        upper_lower_flag = 0
        for i in range(0,len(self.vmodel.dn_x),1):
            for j in range(0,len(self.vmodel.dn_x[i])-1,1):
                if (pts_x_z[0] - self.vmodel.dn_x[i][j]) * (pts_x_z[0] - self.vmodel.dn_x[i][j+1]) <= 0.0:
                    z2 = self.vmodel.dn_z[i][j+1]
                    z1 = self.vmodel.dn_z[i][j]
                    x2 = self.vmodel.dn_x[i][j+1]
                    x1 = self.vmodel.dn_x[i][j]
                    z0 = pts_x_z[1]
                    x0 = pts_x_z[0]
                    temp_distance_to_interface = abs( z0 - ((z2-z1)/(x2-x1)*(x0-x1)+z1) )
                    if temp_distance_to_interface < cur_distance_to_interface:
                        cur_distance_to_interface = temp_distance_to_interface
                        cur_interface = i
                        if z0 - ((z2-z1)/(x2-x1)*(x0-x1)+z1) <= 0.0:
                            upper_lower_flag = 1
                        else:
                            upper_lower_flag = -1
                    break
        return cur_interface, cur_distance_to_interface, upper_lower_flag
                    
        
    
    def show_file_dialog(self):
        # this subfunction calls a filedialog to select the path of working directory
        askdir = filedialog.askdirectory()
        self.data_directory.set(askdir)   
        
    def show_file_dialog_vmodel(self):
        # this subfunction calls a filedialog to select the path of vmodel file.
        askdir_vmodel = filedialog.askdirectory()
        self.vmodel_file_path.set(askdir_vmodel)
        #print(askdir_vmodel)
       
    def radio_select2(self):
        # When block mode is checked, this subfunction is called.
        if self.block_min1.get() == 0 or self.block_max1.get() == 0 or self.block_min2.get() == 0 or self.block_max2.get() == 0:
            messagebox.showinfo("Error Info", "Block Min and max are needed!")
    
    def radio_select1(self):
        # when layer mode is checked, this subfunction is called, but it will not do anything.
        pass
    
    def mode_analysis_visual_radio_select2_func(self):
        pass
    
    def mode_analysis_visual_radio_select1_func(self):
        pass
    
    def show1(content):
        #this subfunction can be used for validation of input. But it is not used in this version.
        if content.isdigit():
            return True
        else:
            messagebox.showinfo("Error Info", "The input shold be numbers!").pack()
            return False
        
    def show2(content):
        #this subfunction can be used for validation of input. But it is not used in this version.
        if isinstance(content, str):
            return True
        else:
            messagebox.showinfo("Error Info", "The input shold be string!").pack()
            return False
    
    def Zoeppritz_RT_plot(self):
        # plot the relection and refraction coefficient based on Zoeppritz equations.
        # the plotting utilizes matplotlib library.
        if self.mode_analysis_visual_no.get() <= 1:
            
            self.model_fig.clear()
            self.model_fig_axs = self.model_fig.add_subplot(111)
            self.model_fig_axs.clear()
            alpha_num = int((self.alpha2 - self.alpha1)/self.alpha_step + 1)
            alpha_list = [(self.alpha1+self.alpha_step*i)*180.0/pi for i in range(0,alpha_num,1)]
            
            self.model_fig_axs.plot(alpha_list,[abs(RT_val) for RT_val in self.Rpp_list],'k',linewidth=1)
            self.model_fig_axs.plot(alpha_list,[abs(RT_val) for RT_val in self.Rps_list],'g',linewidth=1)
            self.model_fig_axs.plot(alpha_list,[abs(RT_val) for RT_val in self.Tpp_list],'b',linewidth=1)
            self.model_fig_axs.plot(alpha_list,[abs(RT_val) for RT_val in self.Tps_list],'r',linewidth=1)
            
            self.model_fig_axs.set_xlim((min(alpha_list),max(alpha_list)))
            #self.model_fig_axs.set_ylim((self.vmodel.dn_z[0][0], self.vmodel.dn_z[-1][0]))
            #self.model_fig_axs.invert_yaxis()
            self.model_fig_axs.set_xlabel("Incident Angle (degree)")
            self.model_fig_axs.set_ylabel("R,T Coefficient")
            self.model_fig_axs.set_title("R,T Coefficient from Zoeppritz Equation")
            #self.model_fig_axs.plot(self.vmodel.dn_x[1],self.vmodel.dn_z[1],'g',label='Line 1', linewidth=2)
            self.model_canvas.draw()
            
            self.show_text.insert(tkinter.END, "\nRed for Tps\nGreen for Rps\nBlue for Tpp\nBlack for Rpp\n")
            
        elif self.mode_analysis_visual_no.get() == 2:
            
            self.model_fig.clear()
            self.model_fig_axs = self.model_fig.add_subplot(111)
            self.model_fig_axs.clear()
            
            self.model_fig_axs.plot(self.mode_analysis_varia_distance_list, self.mode_analysis_Rpp_varia_list, 'k', linewidth=1)
            self.model_fig_axs.plot(self.mode_analysis_varia_distance_list, self.mode_analysis_Rps_varia_list, 'b', linewidth=1)
            self.model_fig_axs.plot(self.mode_analysis_varia_distance_list, self.mode_analysis_Tpp_varia_list, 'g', linewidth=1)
            self.model_fig_axs.plot(self.mode_analysis_varia_distance_list, self.mode_analysis_Tps_varia_list, 'r', linewidth=1)
            
            self.model_fig_axs.set_xlim((min(self.mode_analysis_varia_distance_list),max(self.mode_analysis_varia_distance_list)))
            #self.model_fig_axs.set_ylim((self.vmodel.dn_z[0][0], self.vmodel.dn_z[-1][0]))
            #self.model_fig_axs.invert_yaxis()
            self.model_fig_axs.set_xlabel("Distance (km)")
            self.model_fig_axs.set_ylabel("R,T Coefficient (%)")
            self.model_fig_axs.set_title("R,T Coefficient from Zoeppritz Equation (Spatial Variation)")
            #self.model_fig_axs.plot(self.vmodel.dn_x[1],self.vmodel.dn_z[1],'g',label='Line 1', linewidth=2)
            self.model_canvas.draw()
            
            self.show_text.insert(tkinter.END, "\nRed for Tps\nBlue for Rps\nGreen for Tpp\nBlack for Rpp\n")
        
        else:
            pass
            
            
            
        
    def OnModeAnalysisSpatialClick(self):
        self.alpha1 = float(self.mode_alpha1.get())*pi/180.0
        self.alpha2 = float(self.mode_alpha2.get())*pi/180.0
        self.alpha_step = float(self.mode_alpha_step.get())*pi/180.0
        layer_no = self.mode_interface_select - 1
        x_incre = 1.0
        loop_num = int((float(self.vmodel_x_max.get())-float(self.vmodel_x_min.get()))/x_incre)
        self.Rpp_fraction_temp = 0
        self.Rps_fraction_temp = 0
        self.Tpp_fraction_temp = 0
        self.Tps_fraction_temp = 0
        self.mode_analysis_Rpp_varia_list.clear()
        self.mode_analysis_Rps_varia_list.clear()
        self.mode_analysis_Tps_varia_list.clear()
        self.mode_analysis_Tpp_varia_list.clear()
        self.mode_analysis_varia_distance_list.clear()
        
        if self.mode_upward_downward_incident == 1:
            direc_str = "upward"
        elif self.mode_upward_downward_incident == -1:
            direc_str = "downward"
        else:
            self.show_text.insert(tkinter.END, "\nThe incident direction has not been determined!\n")
            
        fid_Rpp_filename = "Rpp_distance_interface_" + str(layer_no+1) + "_" + direc_str + ".txt"
        fid_Rps_filename = "Rps_distance_interface_" + str(layer_no+1) + "_" + direc_str + ".txt"
        fid_Tpp_filename = "Tpp_distance_interface_" + str(layer_no+1) + "_" + direc_str + ".txt"
        fid_Tps_filename = "Tps_distance_interface_" + str(layer_no+1) + "_" + direc_str + ".txt"
        fid_Rpp = open(fid_Rpp_filename, 'w')
        fid_Rps = open(fid_Rps_filename, 'w')
        fid_Tpp = open(fid_Tpp_filename, 'w')
        fid_Tps = open(fid_Tps_filename, 'w')
        
        for i in range(0, loop_num+1, 1):
            x_analysis = x_incre*i + float(self.vmodel_x_min.get())
            
            for j in range(0, len(self.vmodel.lv_x[layer_no])-1, 1):
                if (x_analysis - self.vmodel.lv_x[layer_no][j])*(x_analysis - self.vmodel.lv_x[layer_no][j+1])<=0.0:
                    vp1 = self.vmodel.lv[layer_no][j]
                    break
            
            for j in range(0, len(self.vmodel.uv_x[layer_no+1])-1, 1):
                if (x_analysis - self.vmodel.uv_x[layer_no+1][j])*(x_analysis - self.vmodel.uv_x[layer_no+1][j+1])<=0.0:
                    vp2 = self.vmodel.uv[layer_no+1][j]
                    break
                
            for j in range(0, len(self.vmodel.dn_x[layer_no])-1, 1):
                if (x_analysis - self.vmodel.dn_x[layer_no][j])*(x_analysis - self.vmodel.dn_x[layer_no][j+1])<=0.0:
                    z = self.vmodel.dn_z[layer_no][j]
                    break
        
            vs1 = self.vp_to_vs(vp1, layer_no, 1)
            vs2 = self.vp_to_vs(vp2, layer_no, -1)
            ro1 = self.vp_to_density(vp1, z)
            ro2 = self.vp_to_density(vp2, z)
            
            if self.mode_upward_downward_incident == 1:
                vp1,vp2 = vp2,vp1
                vs1,vs2 = vs2,vs1
                ro1,ro2 = ro2,ro1
                
#            print(x_analysis, vp1, vp2, vs1, vs2, ro1, ro2)
            self.alpha1 = float(self.mode_alpha1.get())*pi/180.0
            self.alpha2 = float(self.mode_alpha2.get())*pi/180.0
            self.alpha_step = float(self.mode_alpha_step.get())*pi/180.0
            [self.Rpp_list,self.Rps_list,self.Tpp_list,self.Tps_list, self.Rpp_mean,self.Rps_mean,self.Tpp_mean,self.Tps_mean] = \
            Zoeppritz_solver_integral(self.alpha1, self.alpha2, self.alpha_step, vp1, vs1, ro1, \
                                  vp2, vs2, ro2)
            
            Rpp_fraction = abs(self.Rpp_mean)/(abs(self.Rpp_mean)+abs(self.Rps_mean)+abs(self.Tpp_mean)+abs(self.Tps_mean))*100
            Rps_fraction = abs(self.Rps_mean)/(abs(self.Rpp_mean)+abs(self.Rps_mean)+abs(self.Tpp_mean)+abs(self.Tps_mean))*100
            Tpp_fraction = abs(self.Tpp_mean)/(abs(self.Rpp_mean)+abs(self.Rps_mean)+abs(self.Tpp_mean)+abs(self.Tps_mean))*100
            Tps_fraction = abs(self.Tps_mean)/(abs(self.Rpp_mean)+abs(self.Rps_mean)+abs(self.Tpp_mean)+abs(self.Tps_mean))*100
            
            fid_Rpp.write("%f %f\n" %(x_analysis, Rpp_fraction))
            fid_Rps.write("%f %f\n" %(x_analysis, Rps_fraction))
            fid_Tpp.write("%f %f\n" %(x_analysis, Tpp_fraction))
            fid_Tps.write("%f %f\n" %(x_analysis, Tps_fraction))
            
            self.Rpp_fraction_temp += Rpp_fraction
            self.Rps_fraction_temp += Rps_fraction
            self.Tpp_fraction_temp += Tpp_fraction
            self.Tps_fraction_temp += Tps_fraction
            
            self.mode_analysis_Rpp_varia_list.append(Rpp_fraction)
            self.mode_analysis_Rps_varia_list.append(Rps_fraction)
            self.mode_analysis_Tps_varia_list.append(Tps_fraction)
            self.mode_analysis_Tpp_varia_list.append(Tpp_fraction)
            
            self.mode_analysis_varia_distance_list.append(x_analysis)
            
        fid_Rpp.close()
        fid_Rps.close()
        fid_Tpp.close()
        fid_Tps.close()
        
        
        
        
    
    def OnModeAnalysisClick(self):
        # this subfunction is called when mode analysis button is pressed.
        # Zoeppritz_solver is called.
        layer_no = self.mode_interface_select - 1
        
        if self.mode_upward_downward_incident == 1:
            direc_str = "upward"
        elif self.mode_upward_downward_incident == -1:
            direc_str = "downward"
        else:
            self.show_text.insert(tkinter.END, "\nThe incident direction has not been determined!\n")
            
        self.alpha1 = float(self.mode_alpha1.get())*pi/180.0
        self.alpha2 = float(self.mode_alpha2.get())*pi/180.0
        self.alpha_step = float(self.mode_alpha_step.get())*pi/180.0
        [self.Rpp_list,self.Rps_list,self.Tpp_list,self.Tps_list, self.Rpp_mean,self.Rps_mean,self.Tpp_mean,self.Tps_mean] = \
        Zoeppritz_solver_integral(self.alpha1, self.alpha2, self.alpha_step, float(self.mode_vp1.get()), float(self.mode_vs1.get()), float(self.mode_ro1.get()), \
                                  float(self.mode_vp2.get()), float(self.mode_vs2.get()), float(self.mode_ro2.get()))
        
        self.show_text.insert(tkinter.END, "\nRpp_mean Rps_mean Tpp_mean Tps_mean\n")
        self.show_text.insert(tkinter.END, "  %7.4f  %7.4f  %7.4f  %7.4f\n" %(self.Rpp_mean,self.Rps_mean,self.Tpp_mean,self.Tps_mean))
        #self.show_text.insert(tkinter.END, "Tps_fraction:%f\n" %(abs(Tps_mean)/(abs(Rpp_mean)+abs(Rps_mean)+abs(Tpp_mean)+abs(Tps_mean))))
        Rpp_fraction = abs(self.Rpp_mean)/(abs(self.Rpp_mean)+abs(self.Rps_mean)+abs(self.Tpp_mean)+abs(self.Tps_mean))*100
        Rps_fraction = abs(self.Rps_mean)/(abs(self.Rpp_mean)+abs(self.Rps_mean)+abs(self.Tpp_mean)+abs(self.Tps_mean))*100
        Tpp_fraction = abs(self.Tpp_mean)/(abs(self.Rpp_mean)+abs(self.Rps_mean)+abs(self.Tpp_mean)+abs(self.Tps_mean))*100
        Tps_fraction = abs(self.Tps_mean)/(abs(self.Rpp_mean)+abs(self.Rps_mean)+abs(self.Tpp_mean)+abs(self.Tps_mean))*100
        
        self.show_text.insert(tkinter.END, "%8.3f%%%8.3f%%%8.3f%%%8.3f%%\n" %(Rpp_fraction,Rps_fraction,Tpp_fraction,Tps_fraction))
        
        self.show_text.insert(tkinter.END, '\n')
        
        fid_Rpp_filename = "Rpp_angle_interface_" + str(layer_no+1) + "_" + direc_str + ".txt"
        fid_Rps_filename = "Rps_angle_interface_" + str(layer_no+1) + "_" + direc_str + ".txt"
        fid_Tpp_filename = "Tpp_angle_interface_" + str(layer_no+1) + "_" + direc_str + ".txt"
        fid_Tps_filename = "Tps_angle_interface_" + str(layer_no+1) + "_" + direc_str + ".txt"
        fid_Rpp = open(fid_Rpp_filename, 'w')
        fid_Rps = open(fid_Rps_filename, 'w')
        fid_Tpp = open(fid_Tpp_filename, 'w')
        fid_Tps = open(fid_Tps_filename, 'w')
        
        temp_angle_list = [self.alpha1 + self.alpha_step*i for i in range(int((self.alpha2 - self.alpha1)/self.alpha_step + 1))]
        
        for i in range(len(self.Rpp_list)):
            fid_Rpp.write("%f %f\n" %(temp_angle_list[i], self.Rpp_list[i]))
            fid_Rps.write("%f %f\n" %(temp_angle_list[i], self.Rps_list[i]))
            fid_Tpp.write("%f %f\n" %(temp_angle_list[i], self.Tpp_list[i]))
            fid_Tps.write("%f %f\n" %(temp_angle_list[i], self.Tps_list[i]))
        
        fid_Rpp.close()
        fid_Rps.close()
        fid_Tpp.close()
        fid_Tps.close()
            
        

    def OnConvert1Click(self):
        #convertor 1, vp/vs ratio to poisson ratio.
        vpvs_to_cal = float(self.cal_vpvs.get())
        pois_caled = 0.5*(1 - 1/(vpvs_to_cal*vpvs_to_cal -1))
        self.cal_pois.set(str(pois_caled))
    
    def OnConvert2Click(self):
        #convertor 2 , poisson's ratio to vp/vs ratio
        pois_to_cal = float(self.cal_pois.get())
        vpvs_caled = (float(2 - 2*pois_to_cal)/(1 - 2*pois_to_cal))**0.5
        self.cal_vpvs.set(str(vpvs_caled))

    def OnRunClick(self):
        # core subfuntion.
        # it is called to start searching in a user-defined range.
        # rayinvr is called here.
        
        if self.search_layer1_no.get() > 0 and self.search_layer1_no.get() <= self.layers_num.get() and \
        self.search_layer2_no.get() > 0 and self.search_layer2_no.get() <= self.layers_num.get() and \
        self.search_layer3_no.get() > 0 and self.search_layer3_no.get() <= self.layers_num.get():
            
            vpvs1_min = float(self.search_layer1_vpvs_min.get())
            vpvs1_max = float(self.search_layer1_vpvs_max.get())
            vpvs1_step = float(self.search_layer1_vpvs_step.get())
            
            vpvs2_min = float(self.search_layer2_vpvs_min.get())
            vpvs2_max = float(self.search_layer2_vpvs_max.get())
            vpvs2_step = float(self.search_layer2_vpvs_step.get())
            
            vpvs3_min = float(self.search_layer3_vpvs_min.get())
            vpvs3_max = float(self.search_layer3_vpvs_max.get())
            vpvs3_step = float(self.search_layer3_vpvs_step.get())
            
            layer1_no = int(self.search_layer1_no.get())
            layer2_no = int(self.search_layer2_no.get())
            layer3_no = int(self.search_layer3_no.get())
            
            
            temp_splited = self.layer_pois.get().strip().split(',')
            layer_pois_list = [float(elem) for elem in temp_splited]
            
            n1 = int((vpvs1_max - vpvs1_min)/vpvs1_step) + 1
            n2 = int((vpvs2_max - vpvs2_min)/vpvs2_step) + 1
            n3 = int((vpvs3_max - vpvs3_min)/vpvs3_step) + 1
            
            vpvs1_list = [vpvs1_min+vpvs1_step*i for i in range(0,n1,1)]
            vpvs2_list = [vpvs2_min+vpvs2_step*i for i in range(0,n2,1)]
            vpvs3_list = [vpvs3_min+vpvs3_step*i for i in range(0,n3,1)]
            
            
    #        vpvs1_list = [2.6+0.02*i for i in range(16)]
    #        vpvs2_list = [2.1+0.02*j for j in range(11)]
            #pois1_list = [0.5*(1 - 1/(vpvs*vpvs -1)) for vpvs in vpvs1_list]
            #pois2_list = [0.5*(1 - 1/(vpvs*vpvs -1)) for vpvs in vpvs2_list]
            #print(vpvs1_list)
            #print(vpvs2_list)
            
           
            vpvs1_2_3_pts_rms_chi2 = [[0,0,0,0,0,0] for i in range(0,len(vpvs1_list)*len(vpvs2_list)*len(vpvs3_list),1)]
            os.chdir(self.data_directory.get())
            os.mkdir(self.test_directory.get())
            os.chdir(self.test_directory.get())
            test_dir = os.getcwd()
            os.chdir(self.data_directory.get())
            
            
            index1 = 0 
            results_file_obj = open('%s_results_layer1_%d_block_%d_%d_layer2_%d_block_%d_%d_layer3_%d_block_%d_%d_vpvs1_%f_%f_vpvs2_%f_%f_vpvs3_%f_%f.txt' \
                                    %(self.result_filename_prefix.get(), layer1_no,self.block_min1.get(),self.block_max1.get(),layer2_no,self.block_min2.get(),self.block_max2.get(),layer3_no,self.block_min3.get(),self.block_max3.get(), \
                                      min(vpvs1_list),max(vpvs1_list),min(vpvs2_list),max(vpvs2_list),min(vpvs3_list),max(vpvs3_list)), 'w')
            old_time = datetime.now()
            seconds_consumed = 0
            
            
            for vpvs1 in vpvs1_list:
                
                for vpvs2 in vpvs2_list:
                    
                    for vpvs3 in vpvs3_list:
                        
                        pois1 = 0.5*(1 - 1/(vpvs1*vpvs1 -1))
                        pois2 = 0.5*(1 - 1/(vpvs2*vpvs2 -1))
                        pois3 = 0.5*(1 - 1/(vpvs3*vpvs3 -1))
                        #print(pois1,pois2)
                        cur_time = datetime.now()
                        duration = cur_time - old_time
                        #print(str(duration.seconds)+'seconds')
                        old_time = datetime.now()
                        if self.search_mode_no.get() == 2:
                            [cur_pts, cur_rms, cur_chi2] = read_write_r_layers_blocks_pois(test_dir, [layer1_no,layer2_no,layer3_no], \
                            [[self.block_min1.get(),self.block_max1.get()],[self.block_min2.get(),self.block_max2.get()],[self.block_min3.get(),self.block_max3.get()]], [pois1,pois2,pois3])
                        if self.search_mode_no.get() == 1:
                            layer_pois_list[layer1_no - 1] = pois1
                            layer_pois_list[layer2_no - 1] = pois2
                            layer_pois_list[layer3_no - 1] = pois3
                            [cur_pts, cur_rms, cur_chi2] = read_write_r_bulk_pois([layer1_no,layer2_no,layer3_no],layer_pois_list,test_dir)
                        if self.search_mode_no.get() == 0:
                            layer_pois_list[layer1_no - 1] = pois1
                            layer_pois_list[layer2_no - 1] = pois2
                            layer_pois_list[layer3_no - 1] = pois3
                            [cur_pts, cur_rms, cur_chi2] = read_write_r_bulk_pois([layer1_no,layer2_no,layer3_no],layer_pois_list,test_dir)
                        
                        vpvs1_2_3_pts_rms_chi2[index1] = [pois1, pois2, pois3, cur_pts, cur_rms, cur_chi2]
                        index1 += 1
                        results_file_obj.write("%5.4f %5.4f %5.4f %5.4f %5.4f %5.4f %6d %8.3f %8.3f\n" %(vpvs1, vpvs2, vpvs3, pois1, pois2, pois3, cur_pts, cur_rms, cur_chi2))
                        #print("%5.2f" %(float(index1)*100/(len(vpvs1_list)*len(vpvs2_list))))
                        self.canvas_progress_bar.coords(self.progress_bar_fill_rec, (0, 0, int(float(index1)*300/(len(vpvs1_list)*len(vpvs2_list)*len(vpvs3_list))), 30))
                        self.perc_search_run.set(str(int(float(index1)*100/(len(vpvs1_list)*len(vpvs2_list)*len(vpvs3_list))))+'%')
                        
                        seconds_consumed += duration.seconds
                        remain_in_secs = int((len(vpvs1_list)*len(vpvs2_list)*len(vpvs3_list) - index1)*float(seconds_consumed)/index1)
                        remain_min = int(remain_in_secs/60)
                        remain_secs = remain_in_secs%60
                        self.search_run_remain_time.set('time remaining '+str(remain_min)+':'+str(remain_secs))
                        
                        
                        if index1 == len(vpvs1_list)*len(vpvs2_list)*len(vpvs3_list):
                            self.perc_search_run.set('Accomplished!')
                        self.update()
                    
                    
            results_file_obj.close()
            
            
        elif self.search_layer1_no.get() > 0 and self.search_layer1_no.get() <= self.layers_num.get() and \
        self.search_layer2_no.get() > 0 and self.search_layer2_no.get() <= self.layers_num.get():
            
            vpvs1_min = float(self.search_layer1_vpvs_min.get())
            vpvs1_max = float(self.search_layer1_vpvs_max.get())
            vpvs1_step = float(self.search_layer1_vpvs_step.get())
            
            vpvs2_min = float(self.search_layer2_vpvs_min.get())
            vpvs2_max = float(self.search_layer2_vpvs_max.get())
            vpvs2_step = float(self.search_layer2_vpvs_step.get())
            
            layer1_no = int(self.search_layer1_no.get())
            layer2_no = int(self.search_layer2_no.get())
            
            
            temp_splited = self.layer_pois.get().strip().split(',')
            layer_pois_list = [float(elem) for elem in temp_splited]
            
            n1 = int((vpvs1_max - vpvs1_min)/vpvs1_step) + 1
            n2 = int((vpvs2_max - vpvs2_min)/vpvs1_step) + 1
            
            vpvs1_list = [vpvs1_min+vpvs1_step*i for i in range(0,n1,1)]
            vpvs2_list = [vpvs2_min+vpvs2_step*i for i in range(0,n2,1)]
            
            
    #        vpvs1_list = [2.6+0.02*i for i in range(16)]
    #        vpvs2_list = [2.1+0.02*j for j in range(11)]
            #pois1_list = [0.5*(1 - 1/(vpvs*vpvs -1)) for vpvs in vpvs1_list]
            #pois2_list = [0.5*(1 - 1/(vpvs*vpvs -1)) for vpvs in vpvs2_list]
            #print(vpvs1_list)
            #print(vpvs2_list)
            
           
            vpvs1_2_pts_rms_chi2 = [[0,0,0,0,0] for i in range(0,len(vpvs1_list)*len(vpvs2_list),1)]
            os.chdir(self.data_directory.get())
            os.mkdir(self.test_directory.get())
            os.chdir(self.test_directory.get())
            test_dir = os.getcwd()
            os.chdir(self.data_directory.get())
            
            index1 = 0 
            results_file_obj = open('%s_results_layer1_%d_block_%d_%d_layer2_%d_block_%d_%d_vpvs1_%f_%f_vpvs2_%f_%f.txt' \
                                    %(self.result_filename_prefix.get(), layer1_no,self.block_min1.get(),self.block_max1.get(),layer2_no,self.block_min2.get(),self.block_max2.get(),min(vpvs1_list),max(vpvs1_list),min(vpvs2_list),max(vpvs2_list)), 'w')
            old_time = datetime.now()
            seconds_consumed = 0
            for vpvs1 in vpvs1_list:
                #search_layer1_vpvs_max = -0.29*vpvs1+2.73
                #vpvs2_list = [search_layer1_vpvs_max - 0.06 + i*0.01 for i in range(13)]
                for vpvs2 in vpvs2_list:
                    pois1 = 0.5*(1 - 1/(vpvs1*vpvs1 -1))
                    pois2 = 0.5*(1 - 1/(vpvs2*vpvs2 -1))
                    #print(pois1,pois2)
                    cur_time = datetime.now()
                    duration = cur_time - old_time
                    #print(str(duration.seconds)+'seconds')
                    old_time = datetime.now()
                    if self.search_mode_no.get() == 2:
                        [cur_pts, cur_rms, cur_chi2] = read_write_r_layers_blocks_pois(test_dir, [layer1_no,layer2_no], [[self.block_min1.get(),self.block_max1.get()],[self.block_min2.get(),self.block_max2.get()]], [pois1,pois2])
                    if self.search_mode_no.get() == 1:
                        layer_pois_list[layer1_no - 1] = pois1
                        layer_pois_list[layer2_no - 1] = pois2
                        [cur_pts, cur_rms, cur_chi2] = read_write_r_bulk_pois([layer1_no,layer2_no],layer_pois_list,test_dir)
                    if self.search_mode_no.get() == 0:
                        layer_pois_list[layer1_no - 1] = pois1
                        layer_pois_list[layer2_no - 1] = pois2
                        [cur_pts, cur_rms, cur_chi2] = read_write_r_bulk_pois([layer1_no,layer2_no],layer_pois_list,test_dir)
                    
                    vpvs1_2_pts_rms_chi2[index1] = [pois1, pois2, cur_pts, cur_rms, cur_chi2]
                    index1 += 1
                    results_file_obj.write("%5.4f %5.4f %5.4f %5.4f %6d %8.3f %8.3f\n" %(vpvs1, vpvs2, pois1, pois2, cur_pts, cur_rms, cur_chi2))
                    #print("%5.2f" %(float(index1)*100/(len(vpvs1_list)*len(vpvs2_list))))
                    self.canvas_progress_bar.coords(self.progress_bar_fill_rec, (0, 0, int(float(index1)*300/(len(vpvs1_list)*len(vpvs2_list))), 30))
                    self.perc_search_run.set(str(int(float(index1)*100/(len(vpvs1_list)*len(vpvs2_list))))+'%')
                    
                    seconds_consumed += duration.seconds
                    remain_in_secs = int((len(vpvs1_list)*len(vpvs2_list) - index1)*float(seconds_consumed)/index1)
                    remain_min = int(remain_in_secs/60)
                    remain_secs = remain_in_secs%60
                    self.search_run_remain_time.set('time remaining '+str(remain_min)+':'+str(remain_secs))
                    
                    
                    if index1 == len(vpvs1_list)*len(vpvs2_list):
                        self.perc_search_run.set('Accomplished!')
                    self.update()
                    
                    
            results_file_obj.close()
            
        elif self.search_layer1_no.get() > 0 and self.search_layer1_no.get() <= self.layers_num.get():
            
            vpvs1_min = float(self.search_layer1_vpvs_min.get())
            vpvs1_max = float(self.search_layer1_vpvs_max.get())
            vpvs1_step = float(self.search_layer1_vpvs_step.get())
            
#            vpvs2_min = float(self.search_layer2_vpvs_min.get())
#            vpvs2_max = float(self.search_layer2_vpvs_max.get())
#            vpvs2_step = float(self.search_layer2_vpvs_step.get())
            
            layer1_no = int(self.search_layer1_no.get())
#            layer2_no = int(self.search_layer2_no.get())
            
            
            temp_splited = self.layer_pois.get().strip().split(',')
            layer_pois_list = [float(elem) for elem in temp_splited]
            
            n1 = int((vpvs1_max - vpvs1_min)/vpvs1_step) + 1
#            n2 = int((vpvs2_max - vpvs2_min)/vpvs1_step) + 1
            
            vpvs1_list = [vpvs1_min+vpvs1_step*i for i in range(0,n1,1)]
#            vpvs2_list = [vpvs2_min+vpvs2_step*i for i in range(0,n2,1)]
            
            
    #        vpvs1_list = [2.6+0.02*i for i in range(16)]
    #        vpvs2_list = [2.1+0.02*j for j in range(11)]
            #pois1_list = [0.5*(1 - 1/(vpvs*vpvs -1)) for vpvs in vpvs1_list]
            #pois2_list = [0.5*(1 - 1/(vpvs*vpvs -1)) for vpvs in vpvs2_list]
            #print(vpvs1_list)
            #print(vpvs2_list)
            
           
            vpvs1_pts_rms_chi2 = [[0,0,0,0] for i in range(0,len(vpvs1_list),1)]
            os.chdir(self.data_directory.get())
            os.mkdir(self.test_directory.get())
            os.chdir(self.test_directory.get())
            test_dir = os.getcwd()
            os.chdir(self.data_directory.get())
            
            index1 = 0 
            results_file_obj = open('%s_results_layer1_%d_block_%d_%d_vpvs1_%f_%f.txt' \
                                    %(self.result_filename_prefix.get(), layer1_no,self.block_min1.get(),self.block_max1.get(),min(vpvs1_list),max(vpvs1_list)), 'w')
            old_time = datetime.now()
            seconds_consumed = 0
            for vpvs1 in vpvs1_list:
                #search_layer1_vpvs_max = -0.29*vpvs1+2.73
                #vpvs2_list = [search_layer1_vpvs_max - 0.06 + i*0.01 for i in range(13)]
                
                pois1 = 0.5*(1 - 1/(vpvs1*vpvs1 -1))
#                pois2 = 0.5*(1 - 1/(vpvs2*vpvs2 -1))
                #print(pois1,pois2)
                cur_time = datetime.now()
                duration = cur_time - old_time
                #print(str(duration.seconds)+'seconds')
                old_time = datetime.now()
                if self.search_mode_no.get() == 2:
                    [cur_pts, cur_rms, cur_chi2] = read_write_r_layers_blocks_pois(test_dir, [layer1_no], [[self.block_min1.get(),self.block_max1.get()]], [pois1])
                if self.search_mode_no.get() == 1:
                    layer_pois_list[layer1_no - 1] = pois1
#                    layer_pois_list[layer2_no - 1] = pois2
                    [cur_pts, cur_rms, cur_chi2] = read_write_r_bulk_pois([layer1_no],layer_pois_list,test_dir)
                if self.search_mode_no.get() == 0:
                    layer_pois_list[layer1_no - 1] = pois1
#                    layer_pois_list[layer2_no - 1] = pois2
                    [cur_pts, cur_rms, cur_chi2] = read_write_r_bulk_pois([layer1_no],layer_pois_list,test_dir)
                
                vpvs1_pts_rms_chi2[index1] = [pois1, cur_pts, cur_rms, cur_chi2]
                index1 += 1
                results_file_obj.write("%5.4f %5.4f %6d %8.3f %8.3f\n" %(vpvs1, pois1, cur_pts, cur_rms, cur_chi2))
                #print("%5.2f" %(float(index1)*100/(len(vpvs1_list)*len(vpvs2_list))))
                self.canvas_progress_bar.coords(self.progress_bar_fill_rec, (0, 0, int(float(index1)*300/(len(vpvs1_list))), 30))
                self.perc_search_run.set(str(int(float(index1)*100/(len(vpvs1_list))))+'%')
                
                seconds_consumed += duration.seconds
                remain_in_secs = int((len(vpvs1_list) - index1)*float(seconds_consumed)/index1)
                remain_min = int(remain_in_secs/60)
                remain_secs = remain_in_secs%60
                self.search_run_remain_time.set('time remaining '+str(remain_min)+':'+str(remain_secs))
                
                
                if index1 == len(vpvs1_list):
                    self.perc_search_run.set('Accomplished!')
                self.update()
                    
                    
            results_file_obj.close()
            
        else:
            self.show_text.insert(tkinter.END, 'No valid layer No. is specified!\n')
            
            
            


    def OnExtractEnter(self,event):
        pass


if __name__ == "__main__":
    app = simpleapp_tk(None)
    app.title('CALM (Converted wAve veLocity Modelling)')
    app.mainloop()