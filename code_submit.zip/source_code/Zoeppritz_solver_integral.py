# -*- coding: utf-8 -*-
"""
Created on Tue Jan  7 00:17:25 2020

@author: ZHY
"""
from Zoeppritz_solver import Zoeppritz_solver
def Zoeppritz_solver_integral(alpha_min, alpha_max, alpha_step, Vp1, Vs1, ro1, Vp2, Vs2, ro2):
    alpha_list = [alpha_min + alpha_step*i for i in range(int((alpha_max - alpha_min)/alpha_step + 1))]
    
    Rpp_list = []
    Rps_list = []
    Tpp_list = []
    Tps_list = []
    
    Rpp_sum = 0
    Rps_sum = 0
    Tpp_sum = 0
    Tps_sum = 0
    
    for alpha in alpha_list:
        [Rpp, Rps, Tpp, Tps] = Zoeppritz_solver(alpha, Vp1, Vs1, ro1, Vp2, Vs2, ro2)
        
        Rpp_list.append(Rpp)
        Rps_list.append(Rps)
        Tpp_list.append(Tpp)
        Tps_list.append(Tps)
        
        Rpp_sum += abs(Rpp)
        Rps_sum += abs(Rps)
        Tpp_sum += abs(Tpp)
        Tps_sum += abs(Tps)

    return Rpp_list, Rps_list,Tpp_list,Tps_list, Rpp_sum/len(alpha_list), Rps_sum/len(alpha_list), Tpp_sum/len(alpha_list), Tps_sum/len(alpha_list)