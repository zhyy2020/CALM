# -*- coding: utf-8 -*-
"""
Created on Sun Nov 10 17:19:15 2019

@author: ZHY
"""
import os
import shutil
from collections import deque
from catTTrms import catTTrmsEach
from catTTrms import catTTrmsPhase
from catTTrms import catTTrmsEachStation

def read_write_r_bulk_pois(layer_no_list, layer_pois_list, test_dir):
    src_rfile_obj = open('r.in', 'r')
    new_rfile_name = 'r_'
    for elem in layer_no_list:
        new_rfile_name += 'layer_' + str(elem) + '_' 
    index = 0
    for elem in layer_no_list:
        new_rfile_name += ('_' + str(elem)+ '_' + '%5.4f' %(layer_pois_list[elem-1]))
        index += 1
    new_rfile_name += '.in'
    new_rfile_obj = open(new_rfile_name, 'w')
    last300Lines = deque(src_rfile_obj, 300)
    line_list = list(last300Lines)
    
    for line in line_list:
        temp_list = line.strip().split('=')
        if len(temp_list) > 0 and temp_list[0] == 'pois':
            
            ori_pois_elem = (temp_list[1].strip()).split(',')
            #print(ori_pois_elem)
            pois_line_str= ' '*11 + 'pois= '
            index = 0
            for ori_pois in ori_pois_elem:
                index += 1
                if ori_pois == '':
                    continue
                if index in layer_no_list:
                    pois_line_str += ' %5.4f,' %(layer_pois_list[index-1])
                else:
                    pois_line_str += (ori_pois_elem[index-1] + ', ')
            pois_line_str += '\n'
            new_rfile_obj.write(pois_line_str)
        else:
            new_rfile_obj.write(line)
            
    #print(new_rfile_name)      
    src_rfile_obj.close()
    new_rfile_obj.close()
    cur_dir = os.getcwd()
    os.chdir(test_dir)
    #print(new_rfile_name)
    os.mkdir(new_rfile_name)
    os.chdir(new_rfile_name)
    
    shutil.copy("%s/%s" %(cur_dir, new_rfile_name),"r.in")
    shutil.copy("%s/tx.in" %cur_dir,"tx.in")
    shutil.copy("%s/v.in" %cur_dir,"v.in")
    
    os.system("xrayinvr > calInfo.txt")
    
    cur_pts, cur_rms, cur_chi2 = catTTrmsEachStation("calInfo.txt")
    
    
    os.chdir(cur_dir)
    return cur_pts, cur_rms, cur_chi2


def read_write_r_layers_blocks_pois(test_dir, poisl_list, poisb_list_list, poisbl_list):
    src_rfile_obj = open('r.in', 'r')
    new_rfile_name = 'r'
    index = 0
    for elem in poisl_list:
        new_rfile_name += ('_' + str(elem)+ '_' +'_'+str(poisb_list_list[index][0])+'_'+str(poisb_list_list[index][len(poisb_list_list[index])-1])+'_'+ '%5.4f' %(poisbl_list[index]))
        index += 1
    new_rfile_name += '.in'
    new_rfile_obj = open(new_rfile_name, 'w')
    last100Lines = deque(src_rfile_obj, 300)
    line_list = list(last100Lines)
    flag=0
    for line in line_list:
        temp_list = line.strip().split('=')
        if len(temp_list) > 0 and temp_list[0] == 'poisl':
            ori_setting = line
            flag=1
            continue
        
        if len(temp_list) > 0 and temp_list[0] == 'poisb':
            index1 = 0
            pois_line_str= ori_setting + ' '*19
            for poisl_val in poisl_list:
                for i in range(min(poisb_list_list[index1]),max(poisb_list_list[index1])+1):
                    pois_line_str += (str(poisl_val)+',')
                pois_line_str += ('\n'+' '*19)
                index1 += 1
                    
            new_rfile_obj.write(pois_line_str)
            ori_setting = line
            flag=1
            continue
        
        if len(temp_list) > 0 and temp_list[0] == 'poisbl':
            index1 = 0
            pois_line_str= ori_setting + ' '*19
            for poisl_val in poisl_list:
                for poisb_val in range(min(poisb_list_list[index1]),max(poisb_list_list[index1])+1):
                    pois_line_str += (str(poisb_val)+',')
                pois_line_str += ('\n'+' '*19)
                index1 += 1
                
            new_rfile_obj.write(pois_line_str)
            ori_setting = line
            flag=1
            continue
        
        if len(temp_list) > 0 and temp_list[0] == 'ray':
            index1 = 0
            pois_line_str= ori_setting + ' '*19
            for poisl_val in poisl_list:
                for poisb_val in range(min(poisb_list_list[index1]),max(poisb_list_list[index1])+1):
                    pois_line_str += ('%6.4f,' %(poisbl_list[index1]))
                pois_line_str += ('\n'+' '*19)
                index1 += 1
                
            new_rfile_obj.write(pois_line_str)
            flag=0
        
        if flag==1:
            ori_setting += line
            continue
        
        if not flag:
            new_rfile_obj.write(line)
            
    #print(new_rfile_name)      
    src_rfile_obj.close()
    new_rfile_obj.close()
    cur_dir = os.getcwd()
    os.chdir(test_dir)
    os.mkdir(new_rfile_name)
    os.chdir(new_rfile_name)
    
    shutil.copy("%s/%s" %(cur_dir, new_rfile_name),"r.in")
    shutil.copy("%s/tx.in" %cur_dir,"tx.in")
    shutil.copy("%s/v.in" %cur_dir,"v.in")
    
    os.system("xrayinvr > calInfo.txt")
    
    cur_pts, cur_rms, cur_chi2 = catTTrmsEachStation("calInfo.txt")
    
    
    os.chdir(cur_dir)
    return cur_pts, cur_rms, cur_chi2
