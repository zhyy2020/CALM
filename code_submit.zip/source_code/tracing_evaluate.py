# -*- coding: utf-8 -*-
"""
Created on Sat Nov 23 15:10:54 2019

@author: ZHY
"""

import os
import sys
import math

def search(path, word):
    fp_list = []
    for filename in os.listdir(path):
        fp = os.path.join(path, filename)
        if os.path.isfile(fp) and word in filename:
            #print(fp)
            fp_list.append(fp)
        elif os.path.isdir(fp):
            search(fp, word)
    return fp_list

def evaluate(self, data_dir, filename_prefix, chi2_share):
    #进入测试文件夹
    os.chdir(data_dir)
    #寻找带有前缀的文件
    lst = search(os.getcwd(), filename_prefix)
    #print(lst)
    #存放追踪信息的字典变量；键为波速比，泊松比组成的字符串，值为追踪数，残差，卡方值组成的列表
    vpvs_trace_dict = {}
    #遍历匹配的文件，填充字典变量
    for fp in lst:
        fid = open(fp, 'r')
        for line in fid:
            line_elems = line.strip().split()
            if len(line_elems) < 5:
                continue
            self.search_layer_num = int((len(line_elems) - 3)/2)
            vpvs_ratio_poisson = ""
            for ii in range(2*self.search_layer_num):
                if ii == 2*self.search_layer_num - 1:
                    vpvs_ratio_poisson = vpvs_ratio_poisson + line_elems[ii]
                else:
                    vpvs_ratio_poisson = vpvs_ratio_poisson + line_elems[ii] + ' '
            
#            vpvs_ratio_poisson = line_elems[0] +' '+ line_elems[1] +' '+ line_elems[2] +' '+ line_elems[3]
            
            phases_traced = int(line_elems[len(line_elems)-3])
            rms = float(line_elems[len(line_elems)-2])
            chi2= float(line_elems[len(line_elems)-1])
            
            vpvs_trace_dict[vpvs_ratio_poisson] = [phases_traced, rms, chi2]
        fid.close()
    
    tx_fid = open('tx.in', 'r')
    #拾取的震相数
    picked_count = 0
    for line in tx_fid:
        line_elems = line.strip().split()
        if line_elems[2] == '0.000':
            continue
        picked_count += 1
    
    tx_fid.close()
    #print(picked_count)
    #形态因子
    shape = 1.0
    #初始化最大的分与相应的键
    max_score = 0.0
    max_score_vpvs_key = ''
    for key in vpvs_trace_dict:
        #提取出 追踪数，残差，卡方值组成的列表
        #temp[0] is traced number, temp[1] is misfit, temp[2] is chi2
        temp = vpvs_trace_dict[key]
        #print(type(temp[2]))
        if temp[2] <=0.0:
            score = 0.0
        else:
            t1 = math.e**((-(math.log(temp[2])-shape**2)**2)/(2*(shape**2)))
            t2 = temp[2]*(math.e**(-0.5*(shape**2)))
            #score = float(temp[0])/picked_count*t1/t2 #Loureiro2016Tectonophy.
            #score = temp[0]**2/temp[2]/(picked_count**2)*100  #specific
            #走时残差，卡方在得分中所占的比重
            #chi2_share = 94.71
            #score = chi2_share/temp[2] + (1 - chi2_share)*(temp[0]/picked_count)**2
            score = chi2_share*(2.0/(1.0/temp[2] + temp[2])) + (1 - chi2_share)*((float(temp[0])/picked_count)**2)
            #寻找最大的分数
            if score > max_score:
                max_score = score
                max_score_vpvs_key = key
        #在值中加入得分情况       
        vpvs_trace_dict[key].append(score)
    
    #print(max_score,max_score_vpvs_key,vpvs_trace_dict[max_score_vpvs_key])
    return max_score,max_score_vpvs_key,vpvs_trace_dict[max_score_vpvs_key]
        
        
        
        