# -*- coding: utf-8 -*-
"""
Created on Thu Mar 21 21:24:29 2019
This module is designed to illustrate the sensitivity of a single layer (including depth and velocity) in a RAYINVR-based forward model.
version 0 (to be continued...)
@author: Haoyu Zhang
@email: haoyuzhang@scsio.ac.cn
"""

class vmodel:
    
    def __init__(self, vfilename, layer, xmin, xmax):
        # dn_x for x coordinates of depth_nodes, dn_h for z coordinates of depth nodes
        x = []
        x1 = []
        val = []
        val1 = []
        self.xMin = xmin
        self.xMax = xmax
        self.dn_x = []
        self.dn_z = []

        #uv for upper velocity
        self.uv_x = []
        self.uv = []
        #lv for lower velocity
        self.lv_x = []
        self.lv = []
        self.pert_v1 = []
        self.pert_z1 = []
        temp = []
        fileID = open(vfilename, 'r')
        lines = fileID.readlines()
        cnt = 0
        for line in lines:
            cnt = cnt + 1
            temp = list(map(float, line.split()[1:]))
            #print(temp)
            if cnt%3 == 1:
                if xmin in temp:
                    x.append(x1)
                    x1 = []
                    val.append(val1)
                    val1 = []
                x1.extend(temp) 
            elif cnt%3 == 2:
                val1.extend(temp)
            else:
                pass
        x.append(x1)
        x1 = []
        val.append(val1)
        val1 = []
        
        fileID.close()
        
        x = [i for i in x if i != []]
        val = [i for i in val if i != []]
        #print(x)
        #print(val)
        
        for i in range(len(x)):
            #dn_x.append(x[i])
            if i%3 == 0:
                self.dn_x.append(x[i])
                self.dn_z.append(val[i])
            elif i%3 == 1:
                self.uv_x.append(x[i])
                self.uv.append(val[i])
            else:
                self.lv_x.append(x[i])
                self.lv.append(val[i])
                
#        print(dn_x)
#        print(dn_z)
#        print(uv_x)
#        print(lv_x)
    def layer_statics(self,layer):
        layer_z_max = max(self.dn_z[layer-1])
        layer_z_min = min(self.dn_z[layer-1])
        layer_uv_max = max(self.uv[layer-1])
        layer_uv_min = min(self.uv[layer-1])
        layer_lv_max = max(self.lv[layer-1])
        layer_lv_min = min(self.lv[layer-1])
        print("z_max:%f\nz_min:%f\nupper_vel_max:%f\nupper_vel_min:%f\nlower_vel_max:%flower_vel_min:%f\n" \
              %(layer_z_max, layer_z_min, layer_uv_max, layer_uv_min, layer_lv_max, layer_lv_min))
        
            
        
    def limit2Pts(self, llimit, ulimit, layer, uld):
        #print(llimit, ulimit)
        import copy
        if uld==2:
            layer_x = copy.deepcopy(self.dn_x[layer-1])
        elif uld==1:
            layer_x = copy.deepcopy(self.lv_x[layer-1])
        elif uld==0:
            layer_x = copy.deepcopy(self.uv_x[layer-1])
        else:
            print("Parameter uld is fault!\n")
        #print(layer_x)
        
            
        i_min_f = 0
        i_max_f = 0
        for i in range(len(layer_x) - 1):
            if ( llimit - layer_x[i])*( llimit - layer_x[i+1]) <= 0.0:
                i_min = i
                i_min_f = 1
                
            if ( ulimit - layer_x[i])*( ulimit - layer_x[i+1]) <= 0.0:
                i_max = i
                i_max_f = 1
#            if i_max_f and i_min_f:
#                break
                
        
        if llimit==self.xMin:
            i_min = -1
            i_min_f = 1
        if ulimit==self.xMax:
            i_max = len(layer_x)-1
            i_max_f = 1
        if i_min_f==0 or i_max_f==0:
            print("limit value is not valid!\n")
        #print("i_min:%d,i_max:%d\n" %(i_min+1,i_max+1))
        return i_min+1,i_max+1
    
    def is_valid(self, modelNo ,xmin, xmax, step):
        import copy
        import numpy as np
        invalid = 0
        invalid_node = []
        temp_dn_x = copy.deepcopy(self.dn_x)
        temp_dn_z = copy.deepcopy(self.dn_z)
        interp_x = [xmin + ij*step for ij in range(int((xmax-xmin)/step) + 1)]
        
        for ij in range(len(temp_dn_x)-1):
            
            interp_y = np.interp(interp_x, temp_dn_x[ij], temp_dn_z[ij])
            
            interp_y1 = np.interp(interp_x, temp_dn_x[ij+1], temp_dn_z[ij+1])
            for jj in range(len(interp_x)):
                if interp_y1[jj] < interp_y[jj]:
                    invalid = 1
                    invalid_node.append([ij+1,jj+1])
        if invalid:
            fid = open("invalid-model%d.txt" %modelNo, 'w')
            for jj in range(len(invalid_node)):
                fid.write("%4d%9.4f\n" %(invalid_node[jj][0], invalid_node[jj][0]*step))
            fid.close()
            return 0
        else:
            return 1
        
                
        
    def rand_pert_layer_out(self, llimit, ulimit, layer, z_pert_min, z_pert_max, z_n, v_id, v_pert_min, v_pert_max, v_n):
        import copy
        [z_n1, z_n2] = self.limit2Pts(llimit, ulimit, layer, 2)
        temp_z = self.dn_z[layer-1][z_n1:z_n2]
        #v_id = 0 represents vel above the layer, while 1 represents vel below
        out_summ_file = open("pert_v_z_summ.txt", 'w')
        out_summ_file.write("pert_v pert_z id\n")
        
        #pert_v = [-v_pert_max+i*(2*float(v_pert_max)/v_n) for i in range(v_n)]
        pert_v = [v_pert_min+i*float(v_pert_max - v_pert_min)/(v_n-1) for i in range(v_n)]
        print(pert_v)
        self.pert_v1 = pert_v
        #pert_z = [-z_pert_max+i*(2*float(z_pert_max)/z_n) for i in range(z_n)]
        pert_z = [z_pert_min+i*float(z_pert_max - z_pert_min)/(z_n-1) for i in range(z_n)]
        print(pert_z)
        self.pert_z1 = pert_z
        
        for i in range(len(pert_v)):
            for j in range(len(pert_z)):
                outFileCnt = i*len(pert_z) + j
                out_summ_file.write("%7.2f%7.2f%4d\n" %(pert_v[i],pert_z[j],outFileCnt))
                outFileName = "v-%d.in" %(outFileCnt)
                outFileID = open(outFileName, 'w')
                temp_dn_x = copy.deepcopy(self.dn_x)
                temp_dn_z = copy.deepcopy(self.dn_z)
                temp_uv_x = copy.deepcopy(self.uv_x)
                temp_lv_x = copy.deepcopy(self.lv_x)
                temp_uv = copy.deepcopy(self.uv)
                temp_lv = copy.deepcopy(self.lv)
                #print(i,j,i*len(pert_z) + j,pert_v[i],pert_z[j],outFileName)
                if v_id == 0:
                    
                    [v_n1, v_n2] = self.limit2Pts(llimit, ulimit, layer-1, 1)
                    temp_v = copy.deepcopy(temp_lv[layer-2][v_n1:v_n2])
                    #print(v_n1,v_n2)
                    #print(temp_v)
                    temp_v = [temp_v[jj]+pert_v[i] for jj in range(len(temp_v))]
                    #print(temp_v)
                    temp_lv[layer-2][v_n1:v_n2] = copy.deepcopy(temp_v)
                    
                elif v_id == 1:
                    
                    [v_n1, v_n2] = self.limit2Pts(llimit, ulimit, layer, 0)
                    temp_v = copy.deepcopy(temp_uv[layer-1][v_n1:v_n2])
                    #print(temp_v)
                    temp_v = [temp_v[jj]+pert_v[i] for jj in range(len(temp_v))]
                    #print(temp_v)
                    temp_uv[layer-1][v_n1:v_n2] = copy.deepcopy(temp_v)
                else:
                    print("v_id in rand_pert_layer_out is fault\n")
                
                temp_z = copy.deepcopy(temp_dn_z[layer-1][z_n1:z_n2])
                #print(temp_z)
                temp_z = [temp_z[jj]+pert_z[j] for jj in range(len(temp_z))]
                temp_dn_z[layer-1][z_n1:z_n2] = copy.deepcopy(temp_z)
                #print(temp_z)
                
                for k in range(len(temp_dn_x)-1):
                    for arr_i in [1,2,3]:
                        if arr_i == 1:
                            xx = temp_dn_x[k]
                            xz = temp_dn_z[k]
                        elif arr_i == 2:
                            xx = temp_uv_x[k]
                            xz = temp_uv[k]
                        else:
                            xx = temp_lv_x[k]
                            xz = temp_lv[k]
                        #print(len(xx))
                        line1 = "%2d " %(k+1)
                        line2 = "%2d " %(1)
                        line3 = 3*' '
                        
                        if len(xx) <=10:
                            line2 = "%2d " %(0)
                            for l in range(len(xx)):
                                
                                line1 = line1 + "%7.2f" %(xx[l])
                                line2 = line2 + "%7.2f" %(xz[l])
                                line3 = line3 + 6*' ' + '%1d' %(1)
                            line1 = line1 + '\n'
                            line2 = line2 + '\n'
                            line3 = line3 + '\n'
                            
                            line_temp = line1 + line2 + line3
                            outFileID.writelines(line_temp)
                        else:
                            segment = int(len(xx)/10)
                            #print(segment)
                            
                            for kk in range(1,segment+1):
                                if kk*10 == len(xx):
                                    did = 0
                                else:
                                    did = 1
                                line1 = "%2d " %(k+1)
                                line2 = "%2d " %(did)
                                line3 = 3*' '
                                
                                for kkk in range((kk-1)*10, kk*10):
                                    line1 += "%7.2f" %(xx[kkk])
                                    line2 += "%7.2f" %(xz[kkk])
                                    line3 += 6*' ' + '%1d' %(1)
                                line1 = line1 + '\n'
                                line2 = line2 + '\n'
                                line3 = line3 + '\n'
                                
                                line_temp = line1 + line2 + line3
                                outFileID.writelines(line_temp)
                            remain = len(xx)%10
                            if remain == 0:
                                pass
                            else:
                                line1 = "%2d " %(k+1)
                                line2 = "%2d " %(0)
                                line3 = 3*' '
                                for kkk in range(kk*10,len(xx)):
                                    line1 += "%7.2f" %(xx[kkk])
                                    line2 += "%7.2f" %(xz[kkk])
                                    line3 += 6*' ' + '%1d' %(1)
                                line1 = line1 + '\n'
                                line2 = line2 + '\n'
                                line3 = line3 + '\n'
                            
                                line_temp = line1 + line2 + line3
                                outFileID.writelines(line_temp)
                
                xx = temp_dn_x[-1]
                xz = temp_dn_z[-1]
                line1 = "%2d " %(len(temp_dn_x))
                line2 = "%2d " %(0)
                for l in range(len(xx)):
                                
                    line1 = line1 + "%7.2f" %(xx[l])
                    line2 = line2 + "%7.2f" %(xz[l])
                    
                line1 = line1 + '\n'
                line2 = line2 + '\n'
                
                
                line_temp = line1 + line2
                outFileID.writelines(line_temp)
                outFileID.close()
                    
        out_summ_file.close()
        
        print("depth_nodes perturbated:%d-%d\nvel_nodes perturbated:%d-%d\n" %(z_n1, z_n2-1, v_n1, v_n2-1))  
        

def catSummInfo(iout):
    #import os
    from collections import deque
    #os.chdir("temp")
    ioutObj = open("i.out", 'r')
    last6Line = deque(ioutObj,6)
    list1 = list(last6Line)
    #print(list1)
    
    #line = output.pop()
    #line = output.pop()
    #line = output.pop()
    #line = output.pop()
    #print(line)
    pts = 0
    rms = 0
    chi2 = 0
    for line in list1:
        if "Number of data points used:" in line:
            line_elem = line.split()
            pts = int(line_elem[-1])
        elif "RMS traveltime residual:" in line:
            line_elem = line.split()
            rms = float(line_elem[-1])
        elif "Normalized chi-squared:" in line:
            line_elem = line.split()
            chi2 = float(line_elem[-1])
        else:
            pass
            #print("Not matched!\n")
    #print(pts,rms,chi2)
    return pts,rms,chi2

#print(test1.limit2Pts(30,40,4))
#rand_pert_layer_out(self, llimit, ulimit, layer, z_pert_max, z_n, v_id, v_pert_max, v_n):