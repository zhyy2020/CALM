The test data contains the basic files (input_files) for running the program properly.
A complete workflow can be carried out using these data.
Travel-time data provided can be used to resolve the shear wave structures in the sediments.
Reference output files (output_files) are also given.
